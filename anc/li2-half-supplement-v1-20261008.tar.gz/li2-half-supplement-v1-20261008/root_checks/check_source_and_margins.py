#!/usr/bin/env python3
"""Root's small independent source check; no old checker is imported.

This is finite evidence at m=4, not the universal source or decay proof.
All algebra is rational.  The only interval library is python-flint/Arb.
"""
from fractions import Fraction as F
from math import comb, factorial, gcd, lcm
from pathlib import Path
import json
from flint import arb, arb_mat, ctx

ctx.prec = 768
out = Path(__file__).resolve().parent
m, g = 4, 2
ii, jj = range(1, 5), range(8)

def U(n): return F(2**n * comb(n+g, g))
def t(n):
    return sum((F(comb(n-h+g,g)*2**(n-h),h) for h in range(1,n+1)),F()) + sum((F(2**n*(-1)**(k-1)*comb(n+g,g-k)*(2**k-1),k) for k in range(1,g+1)),F())
def C(i,j):
    return (U(i)-U(j))/F(j-i) if i!=j else -U(i)*sum((F(1,i+s) for s in range(1,g+1)),F())
def B(i,j):
    if i!=j: return (t(i)-t(j))/F(j-i)
    return sum((F(comb(i-h+g,g)*2**(i-h),h*h) for h in range(1,i+1)),F())-sum((F(2**i*(-1)**k*comb(i+g,g-k),k)*sum((F(2**h-1,h) for h in range(1,k)),F()) for k in range(2,g+1)),F())

def det_q(a):
    a=[list(r) for r in a]; ans=F(1)
    for k in range(len(a)):
        p=next((p for p in range(k,len(a)) if a[p][k]),None)
        if p is None:return F()
        if p!=k:a[k],a[p]=a[p],a[k];ans=-ans
        pivot=a[k][k];ans*=pivot
        for i in range(k+1,len(a)):
            v=a[i][k]/pivot
            for j in range(k+1,len(a)):a[i][j]-=v*a[k][j]
    return ans

def pencil(x):
    return [[C(i,j) for j in jj] for i in ii]+[[B(i,j)-x*(U(i) if i==j else 0) for j in jj] for i in ii]

def mul(a,b):
    c=[F() for _ in range(len(a)+len(b)-1)]
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return c

# Interpolate from five fresh exact determinants.
vals=[det_q(pencil(F(k))) for k in range(5)]
poly=[F() for _ in range(5)]
for k,v in enumerate(vals):
    base=[F(1)];d=F(1)
    for j in range(5):
        if j!=k:base=mul(base,[-F(j),F(1)]);d*=k-j
    for j,c in enumerate(base):poly[j]+=v*c/d
anchor=[4857502578265725101,-33279189820354879920,85498865489060654400,-97625226936695040000,41801476792320000000]
assert [c*2041200000 for c in poly]==anchor
assert det_q(pencil(F(9,7)))==sum((c*F(9,7)**k for k,c in enumerate(poly)),F())

def ball(q):return arb(q.numerator)/q.denominator
R=256
beta_lo=sum((F(1,2**r*r*r) for r in range(1,R+1)),F())
beta_err=F(1,2**R*(R+1)**2)
beta=ball(beta_lo)+arb(0,ball(beta_err))
pv=arb(0)
for c in reversed(poly):pv=pv*beta+ball(c)
rows=[[ball(C(i,j)) for j in jj] for i in ii]
# For g=2 the omitted entry tail is <= 2^(-R-1).
tail=F(1,2**(R+1))
for i in ii:
    row=[]
    for j in jj:
        partial=-sum((F(comb(r-1,2),2**r*(i+r)*(j+r)) for r in range(3,R+1)),F())
        row.append(ball(partial)+arb(0,ball(tail)))
    rows.append(row)
mv=arb_mat(rows).det()
assert pv.overlaps(mv) and not pv.contains(0) and not mv.contains(0)

mod13=[int(c.numerator*pow(c.denominator,-1,13)%13) for c in poly]
assert mod13==[8,5,2,3,3]
assert all(sum(c*pow(x,k,13) for k,c in enumerate(mod13))%13 for x in range(13))

D=lcm(*(c.denominator for c in poly));content=gcd(*(int(c*D) for c in poly));primitive=F(D,content)
alpha=F(1992909,10**6); tau=F(1979,1000)
assert alpha-tau==F(13909,10**6)>0
improved=F(2001629,10**6)
assert improved-tau==F(22629,10**6)>0
report={"status":"FINITE; PASS",
"m":m,"g":g,"polynomial":[str(c) for c in poly],"anchor_denominator":2041200000,
"native_pencil_checks":6,"primitive_scalar":str(primitive),"G4_mod13":mod13,
"beta_tail_bound":str(beta_err),"entry_tail_bound":str(tail),"G4_beta_polynomial":str(pv),"G4_beta_mellin":str(mv),
"log_abs_G4":str(abs(pv).log()),"conservative_margin":str(alpha-tau),"optional_margin":str(improved-tau),
"warning":"No finite computation here proves the uniform H1/H5/H3 statements."}
(out/'root_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','m','native_pencil_checks','primitive_scalar','G4_mod13','log_abs_G4','conservative_margin','optional_margin']},indent=2))
