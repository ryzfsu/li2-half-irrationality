#!/usr/bin/env python3
"""Independent positive-box Arb checker; it imports no code from the other checkers.
All decisions use Arb balls. Floating conversion is only for printed diagnostics.
The formulas and interval obligations are those of the paper.
"""
import json, hashlib, time
from pathlib import Path
from fractions import Fraction
from flint import arb, acb, ctx
ctx.prec = 160
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'reference.json'
R=json.loads(SOURCE.read_text()); DEN=R['denominator']; K=R['fejer_degree']; NC=R['contour_grid_count']
assert K==48 and NC==64
xi,A,B=map(arb,R['geom']); aa=(A+B)/2; bb=(A-B)/2; q=bb/aa
log2=arb(2).log(); I0=arb('1/2')*(arb('1/2').log()-1)
C=arb('9/2')-2*log2; HE=arb('-167/50'); HM=arb('71/25'); TARGET=arb('1992909/1000000')
ke=list(map(arb,R['pinned_edges'])); me=list(map(arb,R['frequency_edges']))
ki=R['pinned_mass']; mi=R['frequency_mass']; vi=R['contour_mass']
assert len(ke)==len(ki)+1 and len(me)==len(mi)+1 and len(vi)==NC
assert sum(ki)+sum(vi)==DEN and sum(mi)==DEN
for ee,ii in [(R['pinned_edges'],ki),(R['frequency_edges'],mi)]:
 for a,b,m in zip(ee[:-1],ee[1:],ii): assert 0<=Fraction(m,DEN)<=Fraction(b)-Fraction(a)
assert all(m>=0 for m in vi) and all(vi[j]==vi[NC-1-j] for j in range(NC))
km=[arb(m)/DEN for m in ki]; mm=[arb(m)/DEN for m in mi]; vm=[arb(m)/DEN for m in vi]
M=arb(sum(vi))/DEN; MK=arb(sum(ki))/DEN
assert xi-A < arb('1/4') and xi+A > arb('5/4')
# The real reference support lies inside the ellipse. Exterior reference arguments -t lie outside.
assert xi-A > arb('-1/2')

def jumps(edges,masses):
 rho=[m/(b-a) for a,b,m in zip(edges[:-1],edges[1:],masses)]
 out=[rho[0]]+[rho[j]-rho[j-1] for j in range(1,len(rho))]+[-rho[-1]]
 return [(e,b) for e,b in zip(edges,out) if b!=0]
kj=jumps(ke,km); mj=jumps(me,mm)
# Real Fourier moments c_n = integral cos(nu) dnu, using exact reflection symmetry.
cn=[M]
for n in range(1,K+1):
 s=sum((vm[j]*(arb.pi()*n*arb(2*j+1)/NC).cos() for j in range(NC//2)),arb(0))*2
 cn.append(arb(K+1-n)/(K+1)*s)
dn=[arb(0)]+[cn[n]*(1+q**n)/n for n in range(1,K+1)]

def hull(vals):
 lo=min(v.lower() for v in vals); hi=max(v.upper() for v in vals)
 return arb((lo+hi)/2,(hi-lo)/2)
def box(a,b):return arb((a+b)/2,(b-a)/2)
def Fpoint(x):return arb(0) if x==0 else x*(abs(x).log()-1)
def F(x):
 if not x.contains(0):return x*(abs(x).log()-1)
 lo=x.lower();hi=x.upper(); vv=[Fpoint(lo),Fpoint(hi),arb(0)]
 if lo<=-1 and hi>=-1:vv.append(arb(1))
 if lo<=1 and hi>=1:vv.append(arb(-1))
 return hull(vv)
def G(x):
 # Used only at exact real endpoints in this checker.
 if x==0:return arb(0)
 assert not x.contains(0)
 return x*x*(abs(x).log()/2-arb('3/4'))
def H(x,l,r):return F(x-l)-F(x-r)
def IH(x,l,r):return G(x-l)-G(x-r)
def realpot(x,jumps):return sum((b*F(x-e) for e,b in jumps),arb(0))
def irealpot(x,jumps):return sum((b*G(x-e) for e,b in jumps),arb(0))
def reflectpot(x,jumps):return -sum((b*F(x+e) for e,b in jumps),arb(0))
def ireflectpot(x,jumps):return -sum((b*G(x+e) for e,b in jumps),arb(0))

def sn(x,upto):
 s=(x-xi)/aa; out=[arb(2),s]
 for n in range(2,upto+1):out.append(s*out[-1]-q*out[-2])
 return out
def vint(x):
 ss=sn(x,K)
 return M*aa.log()-sum((cn[n]*ss[n]/n for n in range(1,K+1)),arb(0))
def ivint(x):
 ss=sn(x,K+1);s=ss[1]
 out=cn[1]*s*s/2
 for n in range(2,K+1):out+=cn[n]/n*(ss[n+1]/(n+1)-q*ss[n-1]/(n-1))
 return M*aa.log()*x-aa*out

def rho(t):
 s=t+xi
 return -2*aa/(s+(s*s-4*aa*bb).sqrt())
def vext(t):
 r=rho(t);z=arb(0)
 for n in range(K,0,-1):z=(z+dn[n])*r
 return M*(aa/(-r)).log()-z
def ivext(t):
 r=rho(t);L=(aa/(-r)).log()
 out=M*(-aa*(L-1)/r-bb*r*(L+1))
 out-=dn[1]*(aa*(-r).log()-bb*r*r/2)
 for n in range(2,K+1):out-=dn[n]*(aa*r**(n-1)/(n-1)-bb*r**(n+1)/(n+1))
 return out

def we(x):
 ve=H(x,arb('1/4'),arb('5/4'))+H(x,arb(0),arb(2))-x*log2-H(x,arb('-1/2'),arb(0))+I0
 return ve-2*realpot(x,kj)-2*vint(x)-reflectpot(x,mj)
def iwe(x):
 ve=IH(x,arb('1/4'),arb('5/4'))+IH(x,arb(0),arb(2))-x*x*log2/2-IH(x,arb('-1/2'),arb(0))+I0*x
 return ve-2*irealpot(x,kj)-2*ivint(x)-ireflectpot(x,mj)
def wu(t):
 vu=F(t+arb('5/4'))-F(t+arb('1/4'))+F(t+2)-F(t)-H(t,arb(0),arb('1/2'))+I0+t*log2
 return vu-2*realpot(t,mj)-reflectpot(t,kj)-vext(t)
def iwu(t):
 vu=G(t+arb('5/4'))-G(t+arb('1/4'))+G(t+2)-G(t)-IH(t,arb(0),arb('1/2'))+I0*t+t*t*log2/2
 return vu-2*irealpot(t,mj)-ireflectpot(t,kj)-ivext(t)

# Upper-half-plane primitive Re(w log(w)-w), with the branch changed on left-hand boxes.
# For Im(w)>=0 and Re(w)<0, log(w)=log(-w)+i*pi; its real correction is -pi Im(w).
def CF(w):
 if w.real.mid()<0:
  return (w*((-w).log(analytic=True)-1)).real-arb.pi()*w.imag
 return (w*(w.log(analytic=True)-1)).real
def wc(v):
 u=arb.pi()*v;z=acb(xi+A*u.cos(),B*u.sin())
 ve=CF(z-arb('1/4'))-CF(z-arb('5/4'))+CF(z)-CF(z-2)-z.real*log2-CF(z+arb('1/2'))+CF(z)+I0
 kp=sum((b*CF(z-e) for e,b in kj),arb(0))
 mr=-sum((b*CF(z+e) for e,b in mj),arb(0))
 vp=M*aa.log()-sum((dn[n]*(u*n).cos() for n in range(1,K+1)),arb(0))
 return ve-2*kp-2*vp-mr

def realpair(e,m,f,h,plus=False):
 out=arb(0)
 for i,mi0 in enumerate(m):
  if mi0==0:continue
  a,b=e[i:i+2]
  for j,mj0 in enumerate(h):
   if mj0==0:continue
   c,d=f[j:j+2]
   v=(G(b+d)-G(a+d)-G(b+c)+G(a+c)) if plus else (G(b-c)-G(a-c)-G(b-d)+G(a-d))
   out+=mi0*mj0*v/((b-a)*(d-c))
 return out

def contour_check():
 stack=[(arb(0),arb(1),0)]; count=0; deepest=0; minlo=None
 while stack:
  a,b,depth=stack.pop();val=wc(box(a,b))
  if val.is_finite() and val>=HE:
   count+=1;deepest=max(deepest,depth);minlo=val.lower() if minlo is None else min(minlo,val.lower())
  else:
   assert depth<30,(a,b,val)
   mid=(a+b)/2;stack.extend([(a,mid,depth+1),(mid,b,depth+1)])
 return {'leaves':count,'max_depth':deepest,'minimum_certified_box_lower':str(minlo)}

def positive_integral(W,IW,h,edges,cutoff=arb('1e-9')):
 # Certified sign-definite boxes use an analytic primitive. Ambiguous boxes use
 # their nonnegative range upper bound, then are summed explicitly in ambiguity_upper.
 total=arb(0);amb=arb(0);counts={'positive':0,'zero':0,'ambiguous':0,'splits':0,'max_depth':0}
 stack=[(a,b,0) for a,b in zip(edges[:-1],edges[1:])]
 cache={}
 def IWcache(x):
  k=str(x)
  if k not in cache:cache[k]=IW(x)
  return cache[k]
 while stack:
  a,b,depth=stack.pop();val=h-W(box(a,b));width=b-a
  assert val.is_finite(),(a,b,val)
  counts['max_depth']=max(counts['max_depth'],depth)
  if val<=0:counts['zero']+=1;continue
  if val>=0:
   v=h*width-IWcache(b)+IWcache(a)
   assert v.upper()>=0,(a,b,v)
   total+=v;counts['positive']+=1;continue
  cap=width*max(arb(0),val.upper())
  if cap<=cutoff:
   total+=arb(cap.upper()/2,cap.upper()/2);amb+=cap;counts['ambiguous']+=1;continue
  assert depth<40,(a,b,val)
  mid=(a+b)/2;stack.extend([(a,mid,depth+1),(mid,b,depth+1)]);counts['splits']+=1
 return total,{'counts':counts,'ambiguity_upper':str(amb.upper())}

def main():
 start=time.time()
 print('reference feasibility: EXACT; finite energy; symmetric nonnegative Fejer density',flush=True)
 qkk=realpair(ke,km,ke,km);qmm=realpair(me,mm,me,mm);qkm=realpair(ke,km,me,mm,True)
 qkv=sum((m*(ivint(b)-ivint(a))/(b-a) for a,b,m in zip(ke[:-1],ke[1:],km) if m!=0),arb(0))
 qmv=sum((m*(ivext(b)-ivext(a))/(b-a) for a,b,m in zip(me[:-1],me[1:],mm) if m!=0),arb(0))
 qvv=M*M*aa.log()-sum((cn[n]*cn[n]*(1+q**n)/n for n in range(1,K+1)),arb(0))
 Q=qkk+qmm+qkm+2*qkv+qmv+qvv
 print('Q =',Q,flush=True)
 cc=contour_check(); print('contour:',cc,flush=True)
 pe,per=positive_integral(we,iwe,HE,ke); print('pinned penalty:',pe,per,flush=True)
 # t>=8: mu_0 support is below 8, |eta_0 support|<=RMAX.
 RMAX=xi+A; assert all(e<8 for e in me)
 T=arb(8);tail=T*log2+T.log()/2+I0-(T+RMAX).log()
 assert tail>HM and log2-1/T>0
 # W_mu(t)>= t log2 + .5 log(t)+I0-log(t+RMAX), increasing for t>=8.
 pm,pmr=positive_integral(wu,iwu,HM,me+[arb(8)]); print('frequency penalty:',pm,pmr,flush=True)
 bound=C+Q+HE+HM-pe-pm
 print('WEAK DUAL ENCLOSURE',bound,flush=True)
 assert bound>TARGET
 receipt={'verdict':'EXACT',
 'reference_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'arb_precision_bits':ctx.prec,'he':str(HE),'hm':str(HM),
 'masses':{'kappa':str(MK),'nu':str(M),'mu':'1'},
 'Q_terms':{name:str(val) for name,val in [('kk',qkk),('mm',qmm),('km',qkm),('kv',qkv),('mv',qmv),('vv',qvv)]},
 'Q':str(Q),'contour':cc,'pinned_penalty':str(pe),'pinned_detail':per,'frequency_penalty':str(pm),'frequency_detail':pmr,
 'frequency_tail_lower_at_8':str(tail),'weak_dual':str(bound),'target':str(TARGET),'strict_target_verified':bool(bound>TARGET),'seconds':time.time()-start}
 (HERE/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2),flush=True)
if __name__=='__main__':main()
