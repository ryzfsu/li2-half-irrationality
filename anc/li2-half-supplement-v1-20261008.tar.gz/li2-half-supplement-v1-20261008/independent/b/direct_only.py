#!/usr/bin/env python3
"""Independent robustness pass: no derivative enclosures; explicit full circle."""
import independent as I
from independent import arb, ar, F
import json,time
start=time.time(); h_eta=ar(F(-1671,500));h_mu=ar(F(711,250));records=[]
# Check finite-difference identities only as diagnostics, never as proof inputs.
for value,deriv,primitive,points in [(I.Wk,I.Wkprime,I.Wkint,[F(33,100),F(57,100),F(91,100),F(113,100)]),(I.Wm,I.Wmprime,I.Wmint,[F(61,100),F(97,100),F(217,100),F(467,100),F(823,100)])]:
    for xx in points:
        x=ar(xx);h=ar(F(1,10**10))
        err1=(value(x+h)-value(x-h))/(2*h)-deriv(x)
        err2=(primitive(x+h)-primitive(x-h))/(2*h)-value(x)
        assert abs(err1)<ar(F(1,10**10)) and abs(err2)<ar(F(1,10**10)),(value.__name__,xx,err1,err2)
print('Derivative and antiderivative diagnostic identities passed.',flush=True)
# Directly enclose every angle, with no use of conjugation to reduce the range.
stack=[(F(j,16),F(j+1,16),0) for j in range(32)];n=0;lowest=arb('inf')
while stack:
    a,b,dep=stack.pop();whole=(I.pi*ar(a)).union(I.pi*ar(b));v=I.Wc(whole)
    if v.is_finite() and v.lower()>=h_eta:
        n+=1;lowest=min(lowest,v.lower());records.append(['circle',str(a),str(b),str(v),str(v.lower()),str(v.upper())])
    else:
        assert dep<25;mid=(a+b)/2;stack.extend([(a,mid,dep+1),(mid,b,dep+1)])
print('Full circle direct intervals',n,lowest,'seconds',time.time()-start,flush=True)

def defects(name,value,primitive,edges,h):
    stack=[(a,b,0) for a,b in zip(edges,edges[1:])];s=arb(0);counts=[0,0,0];tol=ar(F(3,10000))/ar(edges[-1]-edges[0])
    while stack:
        a,b,dep=stack.pop();w=ar(b-a);v=value(ar(a).union(ar(b)))
        assert v.is_finite(),(name,a,b,v)
        if v.lower()>=h:
            upper=arb(0);kind=0
        elif v.upper()<=h:
            upper=(h*w-primitive(ar(b))+primitive(ar(a))).upper();kind=1
        elif h-v.lower()<=tol:
            upper=(w*(h-v.lower())).upper();kind=2
        else:
            assert dep<30;mid=(a+b)/2;stack.extend([(a,mid,dep+1),(mid,b,dep+1)]);continue
        s+=upper;counts[kind]+=1;records.append([name,str(a),str(b),str(v),str(upper),kind,str(v.lower()),str(v.upper())])
    print(name,s,counts,'seconds',time.time()-start,flush=True)
    return s,counts
kd,ks=defects('kappa',I.Wk,I.Wkint,I.ke,h_eta)
md,ms=defects('mu',I.Wm,I.Wmint,I.me+[F(6),F(7),F(8),F(9),F(10)],h_mu)
Q=I.qvalue()['Q0'];bound=I.constant+Q+h_eta+h_mu-kd-md
assert I.Wm(arb(10))>h_mu
assert I.log2-ar(F(1,19))-ar(F(4,11))-ar(F(5000,49249))>0
print('DIRECT_ONLY_BOUND',bound,'seconds',time.time()-start,flush=True)
assert bound>ar(F(1992909,1000000))
json.dump({'status':'PASS','no_derivative_enclosures':True,'full_circle_explicit':True,'h_eta':str(h_eta),'h_mu':str(h_mu),'contour_leaves':n,'contour_lower':str(lowest),'kappa_defect':str(kd),'mu_defect':str(md),'kappa_stats':ks,'mu_stats':ms,'bound':str(bound),'elapsed_seconds':time.time()-start},open(I.Path(__file__).resolve().with_name('direct_only_summary.json'),'w'),indent=2)
json.dump(records,open(I.Path(__file__).resolve().with_name('direct_only_leaves.json'),'w'),indent=1)
