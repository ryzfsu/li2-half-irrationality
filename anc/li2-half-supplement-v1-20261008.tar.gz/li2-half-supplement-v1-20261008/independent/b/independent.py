#!/usr/bin/env python3
"""Independent A1b implementation. Only blind reference.json is mathematical input."""
import json, math, sys, time
from pathlib import Path
from fractions import Fraction as F
from flint import arb, acb, ctx
ctx.prec=100
REF=str(Path(__file__).resolve().with_name('reference.json'))
d=json.load(open(REF)); D=d['denominator']; K=d['fejer_degree']
def ar(x):
    if isinstance(x,arb): return x
    if isinstance(x,F): return arb(x.numerator)/x.denominator
    return arb(x)
def rat(s): return ar(F(s))
xi,A,B=map(rat,d['geom']); aa=(A+B)/2; bb=(A-B)/2; q=bb/aa
log2=arb(2).log(); pi=arb.pi(); constant=arb(9)/2-2*log2
ke=list(map(F,d['pinned_edges'])); me=list(map(F,d['frequency_edges']))
km=[F(x,D) for x in d['pinned_mass']]; mm=[F(x,D) for x in d['frequency_mass']]; cm=[F(x,D) for x in d['contour_mass']]
assert D>0 and K==48
assert list(map(F,d['geom']))==[F(11281,10000),F(12783,10000),F(229,200)]
assert ke==[F(j,32) for j in range(8,41)] and me==[F(j,32) for j in range(16,177)]
assert len(km)==len(ke)-1 and len(mm)==len(me)-1
assert all(w>=0 for w in cm)
assert all(0<=r<=b-a for r,a,b in zip(km,ke,ke[1:]))
assert all(0<=r<=b-a for r,a,b in zip(mm,me,me[1:]))
assert sum(km)+sum(cm)==sum(mm)==1
assert len(cm)==d['contour_grid_count']==64
assert all(cm[j]==cm[-j-1] for j in range(len(cm)))
nu0=ar(sum(cm)); kap0=ar(sum(km))
mom=[nu0]+[(1-ar(k)/ar(K+1))*sum((ar(w)*(pi*F((2*j+1)*k,64).numerator/F((2*j+1)*k,64).denominator).cos() for j,w in enumerate(cm) if w),arb(0)) for k in range(1,K+1)]
# Finite moment support follows from the normalized Fejer kernel, not truncation.
hmom=[arb(0)]+[(1+q**k)*mom[k]/k for k in range(1,K+1)]
kcells=[(ar(a),ar(b),ar(m/(b-a))) for a,b,m in zip(ke,ke[1:],km) if m]
mcells=[(ar(a),ar(b),ar(m/(b-a))) for a,b,m in zip(me,me[1:],mm) if m]

def jumps(edges,masses):
    rho=[m/(b-a) for a,b,m in zip(edges,edges[1:],masses)]
    return [(ar(x),ar(c)) for x,c in zip(edges,[rho[0]]+[y-x for x,y in zip(rho,rho[1:])]+[-rho[-1]]) if c]
kj=jumps(ke,km); mj=jumps(me,mm)

def realprim(x):
    """F(x)=x log|x|-x, including rigorous interval crossings of zero."""
    if x.is_zero(): return arb(0)
    if x>0 or x<0: return x*(abs(x).log()-1)
    # This branch only receives narrow intervals. The range encloses endpoints,
    # zero, and the two possible stationary points +-1.
    lo=x.lower(); hi=x.upper(); vals=[arb(0)]
    for y in (lo,hi):
        if not y.is_zero(): vals.append(y*(abs(y).log()-1))
    if lo<=-1 and hi>=-1: vals.append(arb(1))
    if lo<=1 and hi>=1: vals.append(arb(-1))
    low=min(v.lower() for v in vals); high=max(v.upper() for v in vals)
    return low.union(high)

def secondprim(x):
    if x.is_zero(): return arb(0)
    return x*x*(abs(x).log()/2-ar(3)/4)

def logsegment_real(x,a,b,plus=False):
    return realprim(x+b)-realprim(x+a) if plus else realprim(x-a)-realprim(x-b)

def density_real(x,jps,plus=False):
    return sum((c*(-realprim(x+e) if plus else realprim(x-e)) for e,c in jps),arb(0))

def logsegment_complex(z,a,b):
    za=z-a; zb=z-b
    # Simultaneous branch rotation does not change the real integral.
    if z.real < a:
        la=(-za).log(); lb=(-zb).log()
    else:
        la=za.log(); lb=zb.log()
    return (za*la-zb*lb).real-(b-a)

def density_complex(z,jps,plus=False):
    # A common branch rotation is harmless because sum jumps=0 and
    # sum edge*jumps is real. Branch chosen from the actual support hull.
    pts=[-e if plus else e for e,c in jps]
    flip = z.real < min(pts)
    total=acb(0)
    for e,c in jps:
        w=z+e if plus else z-e
        lp=(-w).log() if flip else w.log()
        total+=c*w*(lp-1)
    return -total.real if plus else total.real

def power_s(x,N=K+1):
    h=(x-xi)/aa; ps=[arb(2),h]
    for k in range(2,N+1): ps.append(h*ps[-1]-q*ps[-2])
    return ps

def nu_inside(x):
    ps=power_s(x,K)
    return nu0*aa.log()-sum((mom[k]*ps[k]/k for k in range(1,K+1)),arb(0))

def nu_inside_int(x):
    ps=power_s(x,K+1)
    ans=nu0*aa.log()*x-mom[1]*(x-xi)**2/(2*aa)
    for k in range(2,K+1):
        ans-=mom[k]/k*aa*(ps[k+1]/(k+1)-q*ps[k-1]/(k-1))
    return ans

def ext_v(t):
    w=t+xi; disc=(w*w-4*aa*bb).sqrt()
    return -2*aa/(w+disc),w,disc

def nu_outside(t):
    v,w,disc=ext_v(t)
    powers=arb(1); ans=nu0*((w+disc)/2).log()
    for k in range(1,K+1):
        powers*=v; ans-=hmom[k]*powers
    return ans

def nu_outside_int(t):
    v,w,disc=ext_v(t)
    ans=nu0*(w*((w+disc)/2).log()-disc)
    vp=[arb(1),v]
    for k in range(2,K+2):vp.append(vp[-1]*v)
    ans-=hmom[1]*(aa*(-v).log()-bb*vp[2]/2)
    for k in range(2,K+1): ans-=hmom[k]*(aa*vp[k-1]/(k-1)-bb*vp[k+1]/(k+1))
    return ans

def nu_contour(u):
    return nu0*aa.log()-sum((hmom[k]*(k*u).cos() for k in range(1,K+1)),arb(0))

def Wk(x):
    V=logsegment_real(x,ar(1)/4,ar(5)/4)+logsegment_real(x,arb(0),arb(2))-x*log2-logsegment_real(x,-ar(1)/2,arb(0))-log2/2-ar(1)/2
    return V-2*density_real(x,kj)-2*nu_inside(x)-density_real(x,mj,True)

def Wm(t):
    V=logsegment_real(t,ar(1)/4,ar(5)/4,True)+logsegment_real(t,arb(0),arb(2),True)+t*log2-logsegment_real(t,ar(0),ar(1)/2)-log2/2-ar(1)/2
    return V-2*density_real(t,mj)-density_real(t,kj,True)-nu_outside(t)

def Wc(u):
    z=acb(xi+A*u.cos(),B*u.sin())
    V=logsegment_complex(z,ar(1)/4,ar(5)/4)+logsegment_complex(z,arb(0),arb(2))-z.real*log2-logsegment_complex(z,-ar(1)/2,arb(0))-log2/2-ar(1)/2
    return V-2*density_complex(z,kj)-2*nu_contour(u)-density_complex(z,mj,True)

def realself(cells):
    ans=arb(0)
    for i,(a,b,ra) in enumerate(cells):
        for j,(c,e,rc) in enumerate(cells[:i+1]):
            v=secondprim(b-c)-secondprim(a-c)-secondprim(b-e)+secondprim(a-e)
            ans+=(1 if i==j else 2)*ra*rc*v
    return ans

def qvalue():
    kk=realself(kcells); mu=realself(mcells)
    kn=sum((rho*(nu_inside_int(b)-nu_inside_int(a)) for a,b,rho in kcells),arb(0))
    nn=nu0*nu0*aa.log()-sum((hmom[k]*mom[k] for k in range(1,K+1)),arb(0))
    kp=arb(0)
    for a,b,ra in kcells:
        for c,e,rc in mcells:
            kp+=ra*rc*(secondprim(b+e)-secondprim(a+e)-secondprim(b+c)+secondprim(a+c))
    np=sum((rho*(nu_outside_int(b)-nu_outside_int(a)) for a,b,rho in mcells),arb(0))
    return {'kk':kk,'kn':kn,'nn':nn,'mm':mu,'km':kp,'nm':np,'Q0':kk+2*kn+nn+mu+kp+np}

def fint(x):return float(x.mid())

if __name__=='__main__':
    print('precision',ctx.prec,'feasible masses',sum(km),sum(cm),sum(mm),'density cap exact')
    print('ellipse',xi,A,B,'aa bb q',aa,bb,q)
    print('q-components',{k:str(v) for k,v in qvalue().items()})
    for func,grid in [(Wc,[pi*j/16 for j in range(17)]),(Wk,[ar(1)/4+ar(j)/32 for j in range(33)]),(Wm,[ar(1)/2+ar(j)/8 for j in range(77)])]:
        print(func.__name__)
        for x in grid: print(fint(x),str(func(x)))

# Centered derivative enclosures are built separately from value enclosures.
def add_segment(Dict,a,b,rho):
    Dict[a]=Dict.get(a,F(0))+rho; Dict[b]=Dict.get(b,F(0))-rho

def combined_jumps(species):
    dd={}
    if species=='eta':
        for a,b,r in [(F(1,4),F(5,4),F(1)),(F(0),F(2),F(1)),(F(-1,2),F(0),F(-1))]:add_segment(dd,a,b,r)
        for a,b,m in zip(ke,ke[1:],km):add_segment(dd,a,b,-2*m/(b-a))
        for a,b,m in zip(me,me[1:],mm):add_segment(dd,-b,-a,-m/(b-a))
    else:
        for a,b,r in [(F(-5,4),F(-1,4),F(1)),(F(-2),F(0),F(1)),(F(0),F(1,2),F(-1))]:add_segment(dd,a,b,r)
        for a,b,m in zip(me,me[1:],mm):add_segment(dd,a,b,-2*m/(b-a))
        for a,b,m in zip(ke,ke[1:],km):add_segment(dd,-b,-a,-m/(b-a))
    return [(ar(e),ar(c)) for e,c in sorted(dd.items()) if c]
eta_j=combined_jumps('eta'); mu_j=combined_jumps('mu')

def nu_inside_prime(x):
    h=(x-xi)/aa; ps=[arb(2),h]; ds=[arb(0),1/aa]
    for k in range(2,K+1):
        ps.append(h*ps[-1]-q*ps[-2]); ds.append(h*ds[-1]+ps[-2]/aa-q*ds[-2])
    return -sum((mom[k]*ds[k]/k for k in range(1,K+1)),arb(0))

def nu_outside_prime(t):
    v,w,disc=ext_v(t); dv=v*v/(aa-bb*v*v)
    return nu0/disc-dv*sum((k*hmom[k]*v**(k-1) for k in range(1,K+1)),arb(0))

def Wkprime(x):
    return sum((c*abs(x-e).log() for e,c in eta_j),arb(0))-log2-2*nu_inside_prime(x)

def Wmprime(x):
    return sum((c*abs(x-e).log() for e,c in mu_j),arb(0))+log2-nu_outside_prime(x)

def Wcprime(u):
    co=u.cos(); si=u.sin(); z=acb(xi+A*co,B*si); zp=acb(-A*si,B*co)
    total=sum((c*(z-e).log() for e,c in eta_j),acb(0))
    return (zp*total).real-zp.real*log2-2*sum((k*hmom[k]*(k*u).sin() for k in range(1,K+1)),arb(0))

def density_real_int(x,jps,plus=False):
    return sum((c*(-secondprim(x+e) if plus else secondprim(x-e)) for e,c in jps),arb(0))

def logsegment_real_int(x,a,b,plus=False):
    return secondprim(x+b)-secondprim(x+a) if plus else secondprim(x-a)-secondprim(x-b)

def Wkint(x):
    V=logsegment_real_int(x,ar(1)/4,ar(5)/4)+logsegment_real_int(x,arb(0),arb(2))-x*x*log2/2-logsegment_real_int(x,-ar(1)/2,arb(0))-x*(log2+1)/2
    return V-2*density_real_int(x,kj)-2*nu_inside_int(x)-density_real_int(x,mj,True)

def Wmint(t):
    V=logsegment_real_int(t,ar(1)/4,ar(5)/4,True)+logsegment_real_int(t,arb(0),arb(2),True)+t*t*log2/2-logsegment_real_int(t,ar(0),ar(1)/2)-t*(log2+1)/2
    return V-2*density_real_int(t,mj)-density_real_int(t,kj,True)-nu_outside_int(t)

def enclosed(func,deriv,a,b):
    lo=ar(a); hi=ar(b); mid=(lo+hi)/2; rad=(hi-lo)/2
    whole=lo.union(hi)
    raw=func(whole)
    if deriv is not None:
        slope=deriv(whole)
        if slope.is_finite():
            centered=func(mid)+(-rad).union(rad)*slope
            raw=raw.intersection(centered) if raw.is_finite() else centered
    assert raw.is_finite(),(func.__name__,str(a),str(b),str(raw))
    return raw
