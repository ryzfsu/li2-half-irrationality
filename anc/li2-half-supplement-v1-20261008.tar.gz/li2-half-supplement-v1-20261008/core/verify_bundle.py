#!/usr/bin/env python3
"""Lightweight assembly replay; this does not rerun all Arb potential cells.

The uniform proofs are in the paper. Full C-A is recomputed separately
with certificates/dual/check_dual.py. No determinant larger than m=32 is used.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import contextlib
import hashlib
import importlib.util
import io
import json
import resource
import runpy
import shutil
import sys
import tempfile
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def log_unit_interval(x, n=80):
    assert 1 <= x <= 2
    y = (x-1)/(x+1)
    lo = 2*sum((y**(2*j+1)/(2*j+1) for j in range(n)), F(0))
    rem = 2*y**(2*n+1)/((2*n+1)*(1-y*y))
    return lo, lo+rem


def log_interval(x):
    x = F(x)
    shift = 0
    while x > 2:
        x /= 2
        shift += 1
    while x < 1:
        x *= 2
        shift -= 1
    lo, hi = log_unit_interval(x)
    a, b = log_unit_interval(F(2))
    return (lo+shift*a, hi+shift*b) if shift >= 0 else (lo+shift*b, hi+shift*a)


def mul(a, b, p):
    c = [0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            c[i+j] = (c[i+j]+x*y) % p
    return c


def evaluate(a, x, p):
    ans = 0
    for v in reversed(a):
        ans = (ans*x+v) % p
    return ans


def main():
    start = time.monotonic()

    # Replay the independent no-corank certificate without mutating its copy.
    arith = module('draft_arithmetic', BASE/'certificates/arithmetic_basic/verify.py')
    output = io.StringIO()
    with tempfile.TemporaryDirectory(prefix='p0-draft-arithmetic-', dir='/tmp') as temp:
        replay = Path(temp)
        shutil.copy2(BASE/'certificates/arithmetic_basic/certificate.json', replay/'certificate.json')
        arith.HERE = replay
        with contextlib.redirect_stdout(output):
            arith.main()
        arithmetic = json.loads((replay/'receipt.json').read_text())
    (BASE/'REPLAY_ARITHMETIC.json').write_text(json.dumps(arithmetic, indent=2)+'\n')
    assert arithmetic['no_corank_used']
    tau = F(arithmetic['tau_upper'])
    assert tau < F(1979,1000)

    # Directed bookkeeping replay. This proves Q and aggregation, not all cells.
    dual_dir = BASE/'certificates/dual'
    sys.path.insert(0, str(dual_dir))
    directed = io.StringIO()
    with contextlib.redirect_stdout(directed):
        runpy.run_path(str(dual_dir/'check_receipt.py'), run_name='__main__')
    (BASE/'REPLAY_DUAL_BOOKKEEPING.txt').write_text(directed.getvalue())

    # The deliberately coarser rational dual comparison printed in the draft.
    ell_upper = F(693147180560,10**12)
    assert log_interval(2)[1] < ell_upper
    penalty_p = F(6905963574153,81920000000000)
    penalty_t = F(38158094390353,409600000000000)
    dual_rational = F(9,2)-2*ell_upper-F(438334707,10**9)-F(669,200)+F(71,25)-penalty_p-penalty_t
    assert dual_rational > F(1992909,10**6)

    # All rounded constants in the linear and quadratic assembly.
    dp, dm = F(751,5000), F(1749,5000)
    # pi < 22/7 bounds log(2*pi) above, with strict slack.
    c_upper = (4*log_interval(F(44,7))[1]+9+F(21,2)*log_interval(2)[1]
               +log_interval(336)[1]+log_interval(F(35,3))[1]+F(5,2)/dp+F(1,2)/dm)
    assert c_upper < F(49979,1000)
    linear_upper = c_upper+log_interval(39)[1]+1+F(12783,10000)
    square_upper = c_upper+log_interval(16)[1]+1+log_interval(F(12783,10000))[1]
    assert linear_upper < 56 and square_upper < 54
    assert 200000*8**20 < 15**20
    rate_lower = 8*log_interval(F(15,8))[0]-F(5,2)*log_interval(5)[1]+2*log_interval(2)[0]
    assert rate_lower > F(239,100)
    assert log_interval(16)[1]+log_interval(15)[1]/2 < F(413,100)
    assert log_interval(15)[1] < F(271,100)

    # Main M=32,p=83 finite source and determinant, then optional p=103 seed.
    seed_dir = BASE/'certificates/seed'
    seed = module('draft_seed', seed_dir/'seed_check.py')
    rational = seed.stage2_rational(32)
    seeds = []
    for p in (83,103):
        data = json.loads((seed_dir/f'seed_m32_p{p}.json').read_text())
        matrix = seed.stage2_mod(32,p)
        assert matrix == seed.rational_reduce(rational,p) == data['matrix']
        value, certificate = seed.determinant_mod(matrix,p)
        assert value == data['determinant_mod_p'] == {83:30,103:42}[p]
        seeds.append({'m':32,'p':p,'entrywise_checks':4096,'determinant_mod_p':value})
    bz = json.loads((seed_dir/'no_roots_bezout_p103.json').read_text())
    f = bz['f_coefficients_ascending']
    assert len(f)==33 and f[0]==42 and f[-1]==35
    one = mul(bz['full_u_coefficients_ascending'],f,103)
    v = bz['v_coefficients_ascending']
    while len(one) < len(v)+103:
        one.append(0)
    for i,a in enumerate(v):
        one[i+103] = (one[i+103]+a)%103
        one[i+1] = (one[i+1]-a)%103
    assert one[0]==1 and all(x==0 for x in one[1:])
    # Degree<=32 plus 33 distinct determinant evaluations identifies f exactly.
    matrix = seed.stage2_mod(32,103)
    for t in range(33):
        pencil = [row[:] for row in matrix]
        for ii,i in enumerate(range(8,40)):
            pencil[32+ii][i] = (pencil[32+ii][i]-t*comb(i+16,16)*pow(2,i,103))%103
        assert seed.determinant_mod(pencil,103)[0] == evaluate(f,t,103)

    result = {
        'status':'PASS',
        'arithmetic_inequalities':arithmetic['checked_integer_dual_inequalities'],
        'arithmetic_low_pieces':arithmetic['low_affine_pieces'],
        'tau_basic_rational':str(tau),
        'alpha_conservative':'1992909/1000000',
        'rational_dual_aggregation_lower':str(dual_rational),
        'linear_constant_upper':str(linear_upper),
        'quadratic_constant_upper':str(square_upper),
        'main_and_optional_seeds':seeds,
        'optional_p103_source_identification_evaluations':33,
        'optional_bezout_identity_verified':True,
        'full_arb_cell_replay_performed_here':False,
        'maximum_determinant_m':32,
        'elapsed_seconds':time.monotonic()-start,
        'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    (BASE/'ASSEMBLY_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('tau_basic_rational','linear_constant_upper','quadratic_constant_upper')},indent=2))


if __name__ == '__main__':
    main()
