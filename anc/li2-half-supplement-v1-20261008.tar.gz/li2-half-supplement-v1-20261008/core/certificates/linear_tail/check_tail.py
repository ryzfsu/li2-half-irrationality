#!/usr/bin/env python3
"""Small exact guards for the native P0 max-frequency replacement theorem."""
from fractions import Fraction as F
from itertools import combinations
from math import comb, factorial
from pathlib import Path
import json

OUT = Path(__file__).resolve().parent
XI, A, B = F(11281,10000), F(12783,10000), F(229,200)

def det(rows):
    a = [list(map(F, row)) for row in rows]
    n = len(a)
    out = F(1)
    for k in range(n):
        q = next((q for q in range(k,n) if a[q][k]), None)
        if q is None:
            return F(0)
        if q != k:
            a[k], a[q] = a[q], a[k]
            out = -out
        v = a[k][k]
        out *= v
        for q in range(k+1,n):
            fac = a[q][k]/v
            for j in range(k+1,n):
                a[q][j] -= fac*a[k][j]
    return out

def prod(xs):
    ans = F(1)
    for x in xs:
        ans *= x
    return ans

def delta(xs):
    return prod(xs[j]-xs[i] for i in range(len(xs)) for j in range(i+1,len(xs)))

def cauchy(xs,ys):
    return delta(xs)*delta(ys)/prod(x+y for x in xs for y in ys)

def weight(g,r):
    return F(comb(r-1,g),2**r)

def insert_map(m,R):
    g = m//2
    r = max(R)
    other = set(R)-{r}
    s = next(x for x in range(g+1,g+m+1) if x not in other)
    return r,s,sorted(other|{s})

def zs(m,p):
    out=[]
    for j in range(p):
        t=F(j+1,p+1)
        co=(1-t*t)/(1+t*t)
        si=2*t/(1+t*t)
        x=m*(XI+A*co)
        y=m*B*si
        assert x > -F(m,6)
        assert x*x+y*y < F(25*m*m,4)
        out.append((x,y))
    return out

def ratio_squared(m,R,L,Z):
    g=m//2
    r,s,Rnew=insert_map(m,R)
    others=set(R)-{r}
    ratio2=(weight(g,r)/weight(g,s))**2
    ratio2*=prod(F((r-u)**4,(s-u)**4) for u in others)
    I=list(range(m//4,5*m//4))
    ratio2*=prod(F((s+i)**2,(r+i)**2) for i in I+L)
    ratio2*=prod(((r+x)**2+y*y)/((s+x)**2+y*y) for x,y in Z)
    return ratio2

def log_interval(x,n=64):
    """Exact rational enclosure, range reduced to x in [1,2]."""
    x=F(x)
    shift=0
    while x>2:
        x/=2
        shift+=1
    while x<1:
        x*=2
        shift-=1
    def atanh_log(t):
        y=(t-1)/(t+1)
        lo=2*sum((y**(2*k+1)/F(2*k+1) for k in range(n)),F(0))
        err=2*y**(2*n+1)/F(2*n+1)/(1-y*y)
        return lo,lo+err
    low,high=atanh_log(x)
    l2,h2=atanh_log(F(2))
    if shift>=0:
        return low+shift*l2,high+shift*h2
    return low+shift*h2,high+shift*l2

def add_intervals(*ints):
    return sum(x[0] for x in ints),sum(x[1] for x in ints)

def scale_interval(c,intv):
    return (c*intv[0],c*intv[1]) if c>=0 else (c*intv[1],c*intv[0])

def display_interval(x):
    # Decimal display is diagnostic; comparisons are rational above.
    return [float(x[0]),float(x[1])]

assert XI-A > -F(1,6)
assert XI+A < F(5,2)
assert B<A
B20_rational=F(3)*F(77,2)*9*F(189,16)
assert B20_rational == F(392931,32)
assert B20_rational < 12500
assert 200000*8**20 < 15**20
assert F(50000)*F(8,15)**20 < F(1,4)

replacement_checks=[]
for m in (4,8,12):
    g=m//2
    H=20*m
    I=list(range(m//4,5*m//4))
    J=list(range(2*m))
    samples=[
        list(range(g+1,g+m))+[H+1],
        list(range(g+1,g+m-1))+[H+1,H+2],
        list(range(H+1,H+m+1)),
        [g+2*j for j in range(1,m)]+[H+11],
        list(range(g+1,g+m))+[7*m*m+1],
    ]
    for R in samples:
        assert len(set(R))==m
        r,s,Rnew=insert_map(m,R)
        others=set(R)-{r}
        D=factorial((m-1)//2)*factorial(m//2)
        assert prod(abs(s-u) for u in others) >= D
        for p in (0,m//2,m):
            S=set(I[:m-p])
            L=[j for j in J if j not in S]
            Z=zs(m,p)
            actual2=ratio_squared(m,R,L,Z)
            raw=(F(2**(3*m//2))*F(77,8)**m*F(189,16)**p
                 *F(m**(2*m),r*r*D*D)*weight(g,r))
            simple=F(12500**m)*F(m*m,4*r*r)*weight(g,r)
            assert actual2 <= raw*raw <= simple*simple
            replacement_checks.append({'m':m,'p':p,'max_r':r,'inserted_s':s,
                'ratio_squared_below_exact_majorant':True,
                'exact_majorant_below_simplified_majorant':True})

# Direct native m=4 check of O1b's pivot-free Laplace expansion.
m=4
g=m//2
I=list(range(m//4,5*m//4))
J=list(range(2*m))
R=[g+1,g+2,g+3,20*m+1]
def U(i):
    return comb(i+g,g)*2**i
C=[[F(U(i)-U(j),j-i) if i!=j else
    -U(i)*sum((F(1,k) for k in range(i+1,i+g+1)),F(0)) for j in J] for i in I]
stack=C+[[F(1,r+j) for j in J] for r in R]
direct=det(stack)
lap=F(0)
for K in combinations(J,m):
    L=[j for j in J if j not in K]
    Cminor=det([[C[i][j] for j in K] for i in range(m)])
    lap+=(-1)**(m*(m-1)//2+sum(K))*Cminor*cauchy(R,L)
assert lap==direct
assert det([[F(1,i+r) for r in R] for i in I])==cauchy(I,R)

# Actual three-Cauchy-minor frequency ratios, using rational real ellipse endpoints.
triple_checks=[]
for p in (0,1,2):
    S=set(I[:m-p])
    Ip=[i for i in I if i not in S]
    Jp=[j for j in J if j not in S]
    Z=[m*(XI-A),m*(XI+A)][:p]
    r,s,Rnew=insert_map(m,R)
    def minors(freq):
        d1=det([[1/(F(i)-z) for z in Z] for i in Ip])
        d2=det([[F(1,i+t) for t in freq] for i in I])
        rows=[-z for z in Z]+list(map(F,freq))
        d3=det([[1/(x+j) for j in Jp] for x in rows])
        return abs(d1*d2*d3)
    direct_ratio=(weight(g,r)/weight(g,s))*minors(R)/minors(Rnew)
    formal2=ratio_squared(m,R,Jp,[(z,F(0)) for z in Z])
    assert direct_ratio**2==formal2
    triple_checks.append({'m':m,'p':p,'exact_triple_minor_ratio_identity':True})

# Exact recurrence coefficients and native quadratic-tail exponent.
coef=[]
for m in (4,8,12,16,32,64,128):
    b=F(15*m,1600)*(F(50000)*F(8,15)**20)**m
    asserted=F(3,320)*F(1,2)**m
    assert b<asserted
    assert b/(1-b)<F(3,160)*F(1,2)**m
    coef.append({'m':m,'b_upper_float':float(b),'claimed_b_float':float(asserted)})
log2,log5,log63,log32over3=(log_interval(x) for x in (2,5,63,F(32,3)))
cU=add_intervals(scale_interval(F(5,2),log5),scale_interval(-2,log2))
a7=add_intervals(scale_interval(7,log63),scale_interval(-35,log2),scale_interval(-1,cU))
c7=add_intervals(log32over3,scale_interval(F(1,2),log63))
assert a7[0]>F(21,10)
assert c7[1]<F(111,25)
assert log63[1]<F(83,20)
assert F(9,100)*52**2 > F(111,25)*52+F(83,20)

data={
'grade':'EXACT derivation, FINITE identity and replacement guards',
'linear_cutoff_K':20,
'exact_constants':{'B20_rational_majorant':str(B20_rational),
 'B20_bound':12500,'geometric_base':str(F(50000)*F(8,15)**20),
 'geometric_base_less_than_one_quarter':True,
 'relative_full_to_cut_envelope':'<= 1 + (3/160) 2^(-m)'},
'replacement_checks':replacement_checks,
'native_pivot_free_laplace_identity':{'m':4,'exact':True,'terms':comb(8,4)},
'native_three_cauchy_ratio_checks':triple_checks,
'recurrence_coefficients':coef,
'quadratic_cutoff':{'R':'7m^2','a7_interval_display':display_interval(a7),
 'c7_interval_display':display_interval(c7),
 'exact_a7_gt_2_1':True,'exact_c7_lt_4_44':True,
 'absolute_tail_le_exp_minus_2_01_m_squared_for_m_ge':52},
'historical_source_hashes_checked':False,
'note':'The mathematical checks above use only this script; historical source paths are not runtime dependencies.',
}
(OUT/'checks.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'pass':True,'replacement_cases':len(replacement_checks),
 'laplace_terms':comb(8,4),'triple_minor_cases':len(triple_checks),
 'K':20,'quadratic_tail_a7':display_interval(a7)},indent=2))
