#!/usr/bin/env python3
"""Cheap, independent normalization and directed-constant checks.

The analytic proof is REPORT.md. Exact rational determinant checks are finite
source guards, not substitutes for its uniform estimates. No m exceeds 8.
"""
from fractions import Fraction as F
from itertools import combinations
from math import comb, prod
from pathlib import Path
import hashlib
import json
import resource
import time

HERE = Path(__file__).resolve().parent


def determinant(matrix):
    a = [[F(v) for v in row] for row in matrix]
    n = len(a)
    ans = F(1)
    for j in range(n):
        i = next((i for i in range(j, n) if a[i][j]), None)
        if i is None:
            return F(0)
        if i != j:
            a[i], a[j] = a[j], a[i]
            ans = -ans
        pivot = a[j][j]
        ans *= pivot
        for i in range(j + 1, n):
            q = a[i][j] / pivot
            for k in range(j + 1, n):
                a[i][k] -= q * a[j][k]
    return ans


def vandermonde(xs):
    return prod((xs[j] - xs[i] for j in range(len(xs)) for i in range(j)), start=F(1))


def cauchy(xs, ys):
    return [[F(1) / (x + y) for y in ys] for x in xs]


def check_product(m, selected, frequencies):
    I = list(range(m // 4, 5 * m // 4))
    J = list(range(2 * m))
    K = list(selected)
    p = m - len(K)
    # Rational contour samples are sufficient to check the rational identity;
    # they are not samples of the actual ellipse or an energy proof.
    Z = [F(2 * a + 1, 2) for a in range(p)]
    R = list(frequencies)
    L = [i for i in I if i not in K]
    H = [j for j in J if j not in K]
    lhs = abs(determinant(cauchy(L, [-z for z in Z])))
    lhs *= abs(determinant(cauchy(I, R)))
    lhs *= abs(determinant(cauchy([-z for z in Z] + R, H)))
    rhs = vandermonde(I) ** 2 * vandermonde(J)
    rhs *= vandermonde(K) ** 2 * vandermonde(Z) ** 2 * vandermonde(R) ** 2
    rhs *= prod((abs(z - k) ** 2 for z in Z for k in K), start=F(1))
    rhs *= prod((k + r for k in K for r in R), start=F(1))
    rhs *= prod((abs(z + r) for z in Z for r in R), start=F(1))
    rhs /= prod((abs(k - i) for k in K for i in I if i != k), start=F(1))
    rhs /= prod((abs(k - j) for k in K for j in J if j != k), start=F(1))
    rhs /= prod((abs(z - i) for z in Z for i in I + J), start=F(1))
    rhs /= prod((r + i for r in R for i in I + J), start=F(1))
    assert lhs == rhs
    k = len(K)
    numerator_degree = (3 * m * m - 2 * m) + k * (k - 1) + p * (p - 1)
    numerator_degree += m * (m - 1) + 2 * k * p + k * m + p * m
    denominator_degree = k * (3 * m - 2) + 3 * m * p + 3 * m * m
    assert numerator_degree - denominator_degree == -2 * m - 2 * p
    h = F(1, m)
    pin_cells = [(F(i, m), F(i + 1, m)) for i in K]
    freq_cells = [(F(r - 1, m), F(r, m)) for r in R]
    assert all(F(1, 4) <= a < b <= F(5, 4) and b - a == h for a, b in pin_cells)
    assert all(a >= F(1, 2) and b - a == h for a, b in freq_cells)
    assert all(b <= a1 for (_, b), (a1, _) in zip(pin_cells, pin_cells[1:]))
    assert all(b <= a1 for (_, b), (a1, _) in zip(freq_cells, freq_cells[1:]))
    assert len(freq_cells) * h == 1 and (len(pin_cells) + p) * h == 1
    return {"m": m, "K": K, "R": R, "product_exact": True,
            "scaling_exponent": numerator_degree - denominator_degree,
            "both_caps_exact": True}


def core_log_interval(x, n=48):
    assert 1 <= x <= 2
    y = (x - 1) / (x + 1)
    lower = 2 * sum((y ** (2 * j + 1) / (2 * j + 1) for j in range(n)), F(0))
    remainder = 2 * y ** (2 * n + 1) / ((2 * n + 1) * (1 - y * y))
    return lower, lower + remainder


def log_interval(x):
    x = F(x)
    assert x > 0
    if x < 1:
        lo, hi = log_interval(1 / x)
        return -hi, -lo
    k = 0
    while x >= 2:
        x /= 2
        k += 1
    lo, hi = core_log_interval(x)
    l2, h2 = core_log_interval(F(2))
    return lo + k * l2, hi + k * h2


def log_low(x):
    return log_interval(x)[0]


def log_high(x):
    return log_interval(x)[1]


def decimal_outward(x, digits, up):
    q, r = divmod(x.numerator * 10 ** digits, x.denominator)
    if up and r:
        q += 1
    sign = "-" if q < 0 else ""
    q = abs(q)
    return f"{sign}{q // 10 ** digits}.{q % 10 ** digits:0{digits}d}"


def main():
    start = time.monotonic()
    checks = []
    for k in range(5):
        for K in combinations(range(1, 5), k):
            checks.append(check_product(4, K, range(3, 7)))
    for K in [[], [2], [3], [2, 4], [3, 5, 8], list(range(2, 10))]:
        checks.append(check_product(8, K, [5, 6, 7, 8, 507, 508, 511, 512]))
    for K in [[], [1, 3], [1, 2, 3, 4]]:
        checks.append(check_product(4, K, [3, 4, 10**6 + 1, 10**6 + 2]))

    scalar_checks = []
    for m in [4, 8]:
        g = m // 2
        for r in [g + 1, g + 2, m, 7 * m * m, 8 * m * m]:
            # Exact equivalent of log binom(r-1,g) <= binomial entropy.
            assert comb(r - 1, g) * g ** g * (r - g) ** (r - g) <= r ** r
            scalar_checks.append({"m": m, "r": r, "binomial_upper_exact": True})
        for i in range(m // 4, 5 * m // 4):
            assert comb(i + g, g) * i ** i * g ** g <= (i + g) ** (i + g)

    xi, A, B = F(11281, 10000), F(12783, 10000), F(229, 200)
    dG, dM = A - xi, F(1, 2) - A + xi
    assert dG == F(751, 5000) and dM == F(1749, 5000)
    assert A > B and A * xi > A * A - B * B and A * (2 - xi) > A * A - B * B
    assert 1 - (xi / A) ** 2 > F(1, 5)
    assert xi + A < F(5, 2)
    assert 2 * F(1, 64) / B < F(1, 8)
    assert 3 * B / 80 > F(1, 32)
    assert log_high(160) < 6
    assert F(1, 2) + A + B < 3
    assert 291 / B < 300

    # pi < 22/7 is used only for an upper bound, so every remaining
    # numerical comparison here consists of rational operations.
    cell_constant = F(9) + 10 * log_high(2) + 4 * log_high(F(44, 7))
    cell_constant += log_high(336) + log_high(F(35, 3)) + log_high(2) / 2
    cell_constant += 5 / (2 * dG) + 1 / (2 * dM)
    assembled_constant = cell_constant + log_high(16 * A) + 1
    linear_cutoff_constant = cell_constant + log_high(39) + 1 + A
    assert cell_constant < 50
    assert assembled_constant < 54
    assert linear_cutoff_constant < 56
    assert F(300) + F(1, 3) + log_high(2) < 302
    assert F(300) + F(1, 3) + F(3, 160) < 301
    assert F(392931, 32) < 12500
    assert 200000 * 8**20 < 15**20
    linear_replacements = []
    for m in [4, 8, 12]:
        g = m // 2
        for R in [list(range(g+1, g+m)) + [20*m+1],
                  list(range(20*m+1, 21*m+1)),
                  list(range(g+1, g+m-1)) + [20*m+1, 30*m+1]]:
            r = max(R)
            others = [u for u in R if u != r]
            s = next(s for s in range(g+1, g+m+1) if s not in others)
            denom = prod(abs(s-u) for u in others)
            from math import factorial
            d_m = factorial((m-1)//2) * factorial(m//2)
            assert denom >= d_m
            # Maximal-frequency replacement: the exact lower-distance bound
            # and all integer constants are verified; the report proves the
            # complex-contour ratio uniformly, not just at selected samples.
            linear_replacements.append({"m": m, "R": R, "removed": r,
                "inserted": s, "distance_product": str(denom),
                "distance_lower_bound": str(d_m)})

    cU_hi = F(5, 2) * log_high(5) - 2 * log_low(2)
    tails = {}
    for Hfactor, s, claimed_rate, claimed_linear, claimed_constant in [
        (8, F(15, 8), F(239, 100), F(413, 100), F(271, 100)),
        (7, F(63, 32), F(21, 10), F(97, 20), F(83, 20)),
    ]:
        ratio = s / (2 - s)
        rate_lower = Hfactor * log_low(s) - cU_hi
        linear_upper = log_high(16) + log_high(ratio) / 2
        constant_upper = log_high(ratio)
        assert rate_lower > claimed_rate
        assert linear_upper < claimed_linear
        assert constant_upper < claimed_constant
        tails[str(Hfactor)] = {
            "s": str(s), "rate_lower": decimal_outward(rate_lower, 24, False),
            "linear_upper": decimal_outward(linear_upper, 24, True),
            "constant_upper": decimal_outward(constant_upper, 24, True),
            "claimed_rate": str(claimed_rate), "claimed_linear": str(claimed_linear),
            "claimed_constant": str(claimed_constant),
        }
    out = {
        "status": "EXACT algebra and rational constants; finite identity guards",
        "maximum_determinant_m": 8,
        "product_checks": checks, "scalar_checks": scalar_checks,
        "tube_constant_300_verified": True,
        "cell_linear_constant_upper_using_pi_lt_22_over_7": decimal_outward(cell_constant, 24, True),
        "assembled_linear_constant_upper": decimal_outward(assembled_constant, 24, True),
        "linear20m_linear_constant_upper": decimal_outward(linear_cutoff_constant, 24, True),
        "linear20m_exact_integer_contraction": True,
        "linear20m_distance_checks": linear_replacements,
        "tail_constants": tails,
        "source_sha256": {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in sorted((HERE / "inputs").glob("*"))},
        "rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "elapsed_seconds": time.monotonic() - start,
    }
    (HERE / "checks.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({k: out[k] for k in ["status", "maximum_determinant_m",
        "tube_constant_300_verified", "cell_linear_constant_upper_using_pi_lt_22_over_7",
        "assembled_linear_constant_upper", "linear20m_linear_constant_upper",
        "linear20m_exact_integer_contraction", "tail_constants", "rss_kib", "elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
