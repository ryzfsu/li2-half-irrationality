#!/usr/bin/env python3
"""Independent exact arithmetic replay; no optimizer and no corank input.

The proof of the native entry bounds, rank capacity, cell coverage, and prime
summation is in REPORT.md. This program checks the finite rational certificate.
"""
from fractions import Fraction as Q
from pathlib import Path
from decimal import Decimal, localcontext
from math import isqrt
import hashlib
import json
import resource
import time

HERE = Path(__file__).resolve().parent
DELTA = Q(1, 128)
INTERCEPTS = (Q(0), Q(1, 4), Q(5, 4), Q(2), Q(-1, 2))


def fl(x):
    return x.numerator // x.denominator


def ce(x):
    return -fl(-x)


def walls(left, right):
    # Every endpoint is b+n*rho with integer n and b in INTERCEPTS.
    result = {left, right}
    for b in INTERCEPTS:
        for c in INTERCEPTS:
            if b <= c:
                continue
            d = b-c
            for n in range(1, fl(d/left)+1):
                x = d/n
                if left < x < right:
                    result.add(x)
    return sorted(result)


def groups(r):
    q = fl(Q(1, 2)/r)
    edges = {(Q(0), 0), (Q(0), 1), (Q(-1, 2), q+1)}
    for endpoint in (Q(1, 4), Q(5, 4), Q(2)):
        edges.add((endpoint, -fl(endpoint/r)))
    ordered = sorted(edges, key=lambda e: e[0]+e[1]*r)
    answer = []
    for a, b in zip(ordered, ordered[1:]):
        va, vb = a[0]+a[1]*r, b[0]+b[1]*r
        assert 0 <= va <= vb <= r
        if va == vb:
            continue
        t = (va+vb)/2
        rr = list(range(ce((Q(1, 4)-t)/r), ce((Q(5, 4)-t)/r)))
        cc = list(range(ce(-t/r), ce((Q(2)-t)/r)))
        answer.append({
            'width': (b[0]-a[0], b[1]-a[1]),
            'its': rr, 'jts': cc,
            'k': int(t >= (q+1)*r-Q(1, 2))
        })
    assert sum((g['width'][0]+g['width'][1]*r for g in answer), Q(0)) == r
    return answer


def geometry_constant(left, right):
    # All possible walls are already present. The probes independently check
    # that the stored affine endpoint ordering is the intended one.
    result = groups((left+right)/2)
    assert result == groups((3*left+right)/4)
    assert result == groups((left+3*right)/4)
    return result


def low_candidates(gs):
    su = [Q(0), Q(0)]
    sk = [Q(0), Q(0)]
    ki = [Q(0), Q(0)]
    kj = [Q(0), Q(0)]
    for g in gs:
        ni, nj = len(g['its']), len(g['jts'])
        for d, width in enumerate(g['width']):
            (sk if g['k'] else su)[d] += min(2*ni, nj)*width
            ki[d] += g['k']*ni*width
            kj[d] += g['k']*nj*width
    return [(1+su[0], su[1]),
            (3-2*ki[0]-kj[0]+sk[0], -2*ki[1]-kj[1]+sk[1])]


def lower_envelope(lines, left, right):
    cuts = {left, right}
    for k, (a, b) in enumerate(lines):
        for c, d in lines[k+1:]:
            if b != d:
                x = (c-a)/(b-d)
                if left < x < right:
                    cuts.add(x)
    cuts = sorted(cuts)
    parts, value = [], Q(0)
    for l, r in zip(cuts, cuts[1:]):
        a, b = min(lines, key=lambda z: z[0]+z[1]*(l+r)/2)
        value += a*(r-l)+b*(r*r-l*l)/2
        parts.append([str(l), str(r), str(a), str(b)])
    return value, parts


def dec(q):
    with localcontext() as ctx:
        ctx.prec = 45
        return str(Decimal(q.numerator)/Decimal(q.denominator))


def main():
    start = time.monotonic()
    raw = (HERE/'certificate.json').read_bytes()
    data = json.loads(raw)
    assert set(data) == {'delta', 'low_cells', 'high_cells', 'provenance'}
    assert Q(data['delta']) == DELTA
    low = Q(0)
    low_parts = []
    low_walls = walls(DELTA, Q(1, 2))
    for left, right in zip(low_walls, low_walls[1:]):
        v, ps = lower_envelope(low_candidates(geometry_constant(left, right)), left, right)
        low += v
        low_parts.extend(ps)
    assert low_parts == data['low_cells']

    high_walls = walls(Q(1, 2), Q(5, 2))
    actual_high_intervals = [(Q(c['lo']), Q(c['hi'])) for c in data['high_cells']]
    assert actual_high_intervals == list(zip(high_walls, high_walls[1:]))
    high, edgechecks, high_parts, dual_count = Q(0), 0, [], 0
    for saved in data['high_cells']:
        left, right = Q(saved['lo']), Q(saved['hi'])
        gs = geometry_constant(left, right)
        lines = []
        for cert in saved['duals']:
            dual_count += 1
            assert left < Q(cert['sample']) < right
            assert gs == groups(Q(cert['sample']))
            canonical = [dict(width=list(map(str, g['width'])), its=g['its'],
                              jts=g['jts'], k=g['k']) for g in gs]
            assert cert['groups'] == canonical
            rows = [(h, t, b, g['k']) for h, g in enumerate(gs)
                    for t in g['its'] for b in (0, 1)]
            cols = [(h, t, g['k']) for h, g in enumerate(gs) for t in g['jts']]
            assert rows == list(map(tuple, cert['rows']))
            assert cols == list(map(tuple, cert['cols']))
            pots = cert['potentials']
            nr = len(rows)
            assert len(pots) == nr+len(cols)
            assert all(type(x) is int for x in pots)
            for ri, (h, t, block, k) in enumerate(rows):
                for ci, (j, s, ell) in enumerate(cols):
                    # g<p; a copy is >=p exactly when its digit is >=1.
                    ti, tj = (k-1)*int(t >= 1), (ell-1)*int(s >= 1)
                    baseline = -min(k, ell) if block == 0 else -min(ti, tj)
                    total = pots[ri]+pots[nr+ci]
                    assert total >= baseline
                    edgechecks += 1
                    if h == j:
                        if t != s:
                            special = baseline+1
                        elif block == 0:
                            special = 0
                        else:
                            special = (2-k) if t >= 1 else 0
                        assert total >= special
                        edgechecks += 1
            assert nr*len(cols) == cert['edge_count']
            a, b = Q(0), Q(0)
            for z, (h, *_) in zip(pots, rows+cols):
                a += z*gs[h]['width'][0]
                b += z*gs[h]['width'][1]
            assert list(map(str, (a, b))) == cert['line']
            lines.append((a, b))
        v, ps = lower_envelope(lines, left, right)
        assert ps == saved['pieces'] and v == Q(saved['integral'])
        high += v
        high_parts.extend(ps)
    assert high == Q(287, 192)

    # A second, compact integration of the claimed high profile.
    table = [
        (Q(1, 2), Q(7, 12), Q(1), Q(0)),
        (Q(7, 12), Q(5, 8), Q(-3, 4), Q(3)),
        (Q(5, 8), Q(2, 3), Q(1, 2), Q(1)),
        (Q(2, 3), Q(3, 4), Q(-3, 2), Q(4)),
        (Q(3, 4), Q(5, 6), Q(-3, 4), Q(3)),
        (Q(5, 6), Q(1), Q(7, 4), Q(0)),
        (Q(1), Q(7, 4), Q(15, 4), Q(-2)),
        (Q(7, 4), Q(2), Q(2), Q(-1)),
        (Q(2), Q(5, 2), Q(0), Q(0))]
    assert sum((a*(r-l)+b*(r*r-l*l)/2 for l, r, a, b in table), Q(0)) == high
    for sl, sr, sa, sb in high_parts:
        l, r, a, b = map(Q, (sl, sr, sa, sb))
        for tl, tr, ta, tb in table:
            if max(l, tl) < min(r, tr):
                assert (a, b) == (ta, tb)

    # Independent finite check of the exact, not rounded, residue-cell counts.
    # No determinant or optimization is computed.
    finite_cases = 0
    all_walls = set(low_walls+high_walls)
    for m in range(4, 65, 4):
        for p in range(3, 5*m//2, 2):
            if any(p % d == 0 for d in range(2, isqrt(p)+1)):
                continue
            if p*p <= 5*m//2-1:
                continue
            rho = Q(p, m)
            if rho in all_walls or rho < DELTA:
                continue
            gs = groups(rho)
            actual = {}
            for v in range(p):
                ii = tuple(n for n in range(0, (5*m//4)//p+2)
                           if m//4 <= v+n*p < 5*m//4)
                jj = tuple(n for n in range(0, (2*m)//p+2) if v+n*p < 2*m)
                k = int(v >= p-(m//2 % p))
                key = (ii, jj, k)
                actual[key] = actual.get(key, 0)+1
            predicted = {}
            for g in gs:
                n = m*(g['width'][0]+g['width'][1]*rho)
                assert n.denominator == 1 and n >= 0
                key = (tuple(g['its']), tuple(g['jts']), g['k'])
                predicted[key] = predicted.get(key, 0)+int(n)
            assert predicted == actual, (m, p, predicted, actual)
            finite_cases += 1

    # Capacity count, universal symbolic coefficients, and a small finite check.
    for h in range(1, 17):
        N = 2*sum(range(h))+3*sum(range(h, 3*h))
        assert N == 13*h*h-4*h
    tail = 2*DELTA+2*DELTA*DELTA
    assert tail == Q(129, 8192)
    log2_lower = sum((2*Q(1, 3)**(2*k+1)/(2*k+1) for k in range(30)), Q(0))
    upper = low+tail+high-Q(13, 16)*log2_lower
    assert upper < Q(1979, 1000)
    assert upper < Q(1978820, 1000000)
    receipt = {
        'verdict': 'EXACT_RATIONAL_CERTIFICATE',
        'certificate_sha256': hashlib.sha256(raw).hexdigest(),
        'no_corank_used': True,
        'low_geometry_intervals': len(low_walls)-1,
        'low_affine_pieces': len(low_parts),
        'high_geometry_intervals': len(data['high_cells']),
        'integer_duals': dual_count,
        'checked_integer_dual_inequalities': edgechecks,
        'finite_exact_residue_count_cases_m_le_64': finite_cases,
        'low_integral': str(low), 'low_integral_decimal': dec(low),
        'tail_upper': str(tail), 'high_integral': str(high),
        'log2_lower': str(log2_lower),
        'tau_upper': str(upper), 'tau_upper_decimal': dec(upper),
        'margin_below_1_979': str(Q(1979, 1000)-upper),
        'margin_below_1_979_decimal': dec(Q(1979, 1000)-upper),
        'margin_to_reported_continuum_lower_1_992909': str(Q(1992909, 1000000)-upper),
        'margin_to_reported_continuum_lower_1_992909_decimal': dec(Q(1992909, 1000000)-upper),
        'seconds': time.monotonic()-start,
        'max_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    }
    (HERE/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
