#!/usr/bin/env python3
"""One-sided arithmetic profile: exact low-band formula, finite high-band duals.

Floating LP is used only to discover integer potentials. Every accepted
potential is checked by integer inequalities; all integration uses Fraction.
"""
import json
from fractions import Fraction as F
from pathlib import Path

BASE = Path(__file__).resolve().parent
def fs(x): return str(x)
def floor(x): return x.numerator // x.denominator
def ceil(x): return -floor(-x)

def geometry(rho):
    # Lines a+b*rho at which copies, or the Kummer flag, change.
    q = floor(F(1,2)/rho)
    lines = [(F(0),0),(F(0),1)]
    for a in (F(1,4),F(5,4),F(2)):
        lines.append((a,-floor(a/rho)))
    lines.append((-F(1,2),q+1))
    lines = sorted(set(lines),key=lambda x:x[0]+x[1]*rho)
    groups = []
    for x,y in zip(lines,lines[1:]):
        lo,hi=x[0]+x[1]*rho,y[0]+y[1]*rho
        if not lo < hi: continue
        v=(lo+hi)/2
        its=list(range(ceil((F(1,4)-v)/rho),ceil((F(5,4)-v)/rho)))
        jts=list(range(0,ceil((F(2)-v)/rho)))
        k=int(v >= (q+1)*rho-F(1,2))
        groups.append(dict(width=(y[0]-x[0],y[1]-x[1]),its=its,jts=jts,k=k))
    return groups

def low_lines(rho):
    """W/m <= min(1+sU,3-2KI-KJ+sK), including special diagonal."""
    su=[F(0),F(0)]; sk=[F(0),F(0)]; ki=[F(0),F(0)]; kj=[F(0),F(0)]
    for g in geometry(rho):
        ni,nj=len(g['its']),len(g['jts']); w=g['width']
        dest=sk if g['k'] else su
        for t in (0,1):
            dest[t]+=min(2*ni,nj)*w[t]
            if g['k']:
                ki[t]+=ni*w[t]; kj[t]+=nj*w[t]
    return [(1+su[0],su[1]),(3-2*ki[0]-kj[0]+sk[0],-2*ki[1]-kj[1]+sk[1])]

def integrate_min(lines,lo,hi):
    cuts={lo,hi}
    for a,b in lines:
        for c,d in lines:
            if b!=d:
                x=(c-a)/(b-d)
                if lo < x < hi: cuts.add(x)
    cuts=sorted(cuts); total=F(0); used=[]
    for x,y in zip(cuts,cuts[1:]):
        r=(x+y)/2; a,b=min(lines,key=lambda z:z[0]+z[1]*r)
        total+=a*(y-x)+b*(y*y-x*x)/2
        used.append([fs(x),fs(y),fs(a),fs(b)])
    return total,used

def cell_breakpoints(lo,hi):
    # All differences of intercepts {0,1/4,5/4,2,-1/2}.
    cs=(F(0),F(1,4),F(5,4),F(2),-F(1,2))
    ds=sorted({abs(a-b) for a in cs for b in cs if a!=b})
    out={lo,hi}
    for d in ds:
        for k in range(1,floor(d/lo)+1):
            x=d/k
            if lo < x < hi:out.add(x)
    return sorted(out)

def high_dual(rho):
    import numpy as np
    from scipy.optimize import linprog
    gs=geometry(rho); rows=[]; cols=[]
    pg=int(rho<=F(1,2))
    for h,g in enumerate(gs):
        for t in g['its']:
            for block in (0,1):rows.append((h,t,block,g['k']))
        for t in g['jts']:cols.append((h,t,g['k']))
    nr=len(rows); nc=len(cols)
    edges={}
    def tau(t,k):return (k-1)*int(t>=1 or pg)
    for i,(h,t,block,k) in enumerate(rows):
        for j,(h2,t2,k2) in enumerate(cols):
            # The global edge is the off-class baseline.
            w=-min(k,k2) if block==0 else -min(tau(t,k),tau(t2,k2))
            edges[i,j]=w
            if h!=h2:continue
            if t!=t2:
                local=w+1
            elif block==0:
                local=(1-k)*pg
            else:
                if pg and 2*rho<=F(1,2):beta=k-2
                else:beta=k-2 if t>=1 else (-1 if pg else 0)
                local=-min(beta,k)
            edges[i,j]=max(w,local)
    # Fix gauge by mu_0=0; potentials may be negative.
    c=[]
    for h,*_ in rows+cols:
        a,b=gs[h]['width'];c.append(float(a+b*rho))
    mat=np.zeros((len(edges),nr+nc)); rhs=[]
    for z,((i,j),w) in enumerate(edges.items()):
        mat[z,i]=mat[z,nr+j]=-1;rhs.append(-w)
    bounds=[(None,None)]*(nr+nc);bounds[nr]=(0,0)
    r=linprog(c,A_ub=mat,b_ub=rhs,bounds=bounds,method='highs')
    assert r.success,r.message
    pots=[int(round(x)) for x in r.x]
    assert max(abs(x-y) for x,y in zip(r.x,pots))<1e-7
    assert all(pots[i]+pots[nr+j]>=w for (i,j),w in edges.items())
    a,b=F(0),F(0)
    for pot,(h,*_) in zip(pots,rows+cols):
        da,db=gs[h]['width'];a+=pot*da;b+=pot*db
    return (a,b),dict(sample=fs(rho),groups=[dict(width=list(map(fs,g['width'])),its=g['its'],jts=g['jts'],k=g['k']) for g in gs],rows=rows,cols=cols,potentials=pots,edge_count=len(edges),line=[fs(a),fs(b)])

def main():
    delta=F(1,128)
    out=dict(delta=fs(delta),low_cells=[],high_cells=[])
    cuts=cell_breakpoints(delta,F(1,2)); low=F(0)
    for lo,hi in zip(cuts,cuts[1:]):
        lines=low_lines((lo+hi)/2);v,pieces=integrate_min(lines,lo,hi);low+=v
        out['low_cells'].extend(pieces)
    # Small-rho tail: lambda_C=1-kappa,lambda_B=2-kappa.
    # KI/m >= frac(1/(2*rho))-rho gives w <= 3-2frac+2rho.
    # Below delta=1/(2Q), integrate each q branch after x=1/(2rho):
    # int_0^delta (3-2frac(1/(2rho))) <= 2delta+delta^2.
    # (A telescoping, positive-series estimate is proved in REPORT.md.)
    tail_hi=2*delta+2*delta*delta
    high=F(0)
    cuts=cell_breakpoints(F(1,2),F(5,2))
    for lo,hi in zip(cuts,cuts[1:]):
        duals=[];seen=set()
        for k in range(1,8):
            line,cert=high_dual(lo+(hi-lo)*F(k,8))
            if line not in seen:duals.append(cert);seen.add(line)
        lines=[tuple(map(F,d['line'])) for d in duals]
        val,pieces=integrate_min(lines,lo,hi);high+=val
        out['high_cells'].append(dict(lo=fs(lo),hi=fs(hi),duals=duals,pieces=pieces,integral=fs(val)))
    # PROPK sections 5 and 6 give upper bounds on the two complete triangles.
    # Replace the high basic bound by those bounds, integrating min exactly.
    corrected=F(0)
    t1=(F(7,12),F(5,8),F(2,3));t2=(F(3,4),F(7,8))
    for cell in out['high_cells']:
        lo,hi=F(cell['lo']),F(cell['hi']);cuts=sorted({lo,hi}|{x for x in (*t1,*t2) if lo<x<hi})
        lines=[tuple(map(F,d['line'])) for d in cell['duals']]
        for a,b in zip(cuts,cuts[1:]):
            mid=(a+b)/2;ls=lines.copy()
            if t1[0]<mid<t1[1]:ls.append((F(1),F(0)))
            if t1[1]<mid<t1[2]:ls.append((-F(3,2),F(4)))
            if t2[0]<mid<t2[1]:ls.append((F(0),F(2)))
            val,pieces=integrate_min(ls,a,b);corrected+=val
    # log(2) lower bound from 2*atanh(1/3), positive series.
    log2lo=sum(2*F(1,3)**(2*k+1)/F(2*k+1) for k in range(30))
    raw=low+tail_hi+high
    corr=low+tail_hi+corrected
    tau= corr-F(13,16)*log2lo
    out['totals']=dict(low_integral=fs(low),tail_upper=fs(tail_hi),high_basic_integral=fs(high),high_corrected_integral=fs(corrected),int_basic_upper=fs(raw),int_corrected_upper=fs(corr),t1t2_credit=fs(high-corrected),log2_lower=fs(log2lo),tau_upper=fs(tau),tau_upper_decimal=float(tau),int_basic_upper_decimal=float(raw))
    (BASE/'integral.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out['totals'],indent=2))
    print('low pieces',len(out['low_cells']),'high cells',len(out['high_cells']))

if __name__=='__main__':main()
