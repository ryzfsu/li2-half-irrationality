#!/usr/bin/env python3
"""Replay all exact certificates and arithmetic, without a floating optimizer."""
import json
import sys
from fractions import Fraction as F
from pathlib import Path
sys.dont_write_bytecode=True
from integrate import geometry,low_lines,cell_breakpoints,integrate_min

BASE=Path(__file__).resolve().parent
d=json.loads((BASE/'integral.json').read_text());tot=d['totals']
delta=F(d['delta']);low=F(0);low_parts=[]
cuts=cell_breakpoints(delta,F(1,2))
for a,b in zip(cuts,cuts[1:]):
    v,parts=integrate_min(low_lines((a+b)/2),a,b);low+=v;low_parts+=parts
assert low_parts==d['low_cells']
assert low==F(tot['low_integral'])

high=F(0);corrected=F(0);edgechecks=0
for cell in d['high_cells']:
    lo,hi=F(cell['lo']),F(cell['hi']);lines=[]
    for cert in cell['duals']:
        sample=F(cert['sample']);gs=geometry(sample)
        assert [dict(width=list(map(str,g['width'])),its=g['its'],jts=g['jts'],k=g['k']) for g in gs]==cert['groups']
        # Type constancy is guaranteed symbolically by the complete wall list;
        # these checks also reject corrupted cell/type records.
        assert geometry(lo+(hi-lo)/4)==gs
        assert geometry(lo+3*(hi-lo)/4)==gs
        rs,cs=cert['rows'],cert['cols'];nr=len(rs);pots=cert['potentials']
        assert len(pots)==nr+len(cs) and all(type(x) is int for x in pots)
        assert [tuple(x) for x in rs]==[(h,t,block,g['k']) for h,g in enumerate(gs) for t in g['its'] for block in (0,1)]
        assert [tuple(x) for x in cs]==[(h,t,g['k']) for h,g in enumerate(gs) for t in g['jts']]
        # Here g<p, so kappa-1 contributes to T only for copies t>=1.
        tau=lambda t,k:(k-1)*int(t>=1)
        for i,(h,t,block,k) in enumerate(rs):
            for j,(h2,t2,k2) in enumerate(cs):
                baseline=-min(k,k2) if block==0 else -min(tau(t,k),tau(t2,k2))
                assert pots[i]+pots[nr+j]>=baseline
                edgechecks+=1
                if h!=h2:continue
                if t!=t2:local=baseline+1
                elif block==0:local=0
                else:local=2-k if t>=1 else 0
                assert pots[i]+pots[nr+j]>=local
                edgechecks+=1
        a,b=F(0),F(0)
        for pot,(h,*_) in zip(pots,rs+cs):
            da,db=gs[h]['width'];a+=pot*da;b+=pot*db
        assert list(map(str,(a,b)))==cert['line']
        lines.append((a,b))
    v,parts=integrate_min(lines,lo,hi)
    assert parts==cell['pieces'] and v==F(cell['integral']);high+=v
    cuts=sorted({lo,hi}|{x for x in [F(7,12),F(5,8),F(2,3),F(3,4),F(7,8)] if lo<x<hi})
    for a,b in zip(cuts,cuts[1:]):
        r=(a+b)/2;ls=lines.copy()
        if F(7,12)<r<F(5,8):ls.append((F(1),F(0)))
        if F(5,8)<r<F(2,3):ls.append((-F(3,2),F(4)))
        if F(3,4)<r<F(7,8):ls.append((F(0),F(2)))
        v,_=integrate_min(ls,a,b);corrected+=v
assert high==F(287,192)==F(tot['high_basic_integral'])
assert corrected==F(95,64)==F(tot['high_corrected_integral'])
assert high-corrected==F(1,96)==F(tot['t1t2_credit'])
tail=2*delta+2*delta*delta
assert tail==F(tot['tail_upper'])
log2lo=sum(2*F(1,3)**(2*k+1)/F(2*k+1) for k in range(30))
assert log2lo==F(tot['log2_lower'])
tau=low+tail+corrected-F(13,16)*log2lo
assert tau==F(tot['tau_upper'])
assert tau<F(1968404,1000000)
print('EXACT: %d integer dual inequalities, %d low pieces, 11 high cells.'%(edgechecks,len(low_parts)))
print('EXACT: high basic 287/192; high corrected 95/64; T1+T2 credit 1/96.')
print('EXACT: tau upper < 1.968404; approximate upper %.15f.'%float(tau))
