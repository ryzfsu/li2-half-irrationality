#!/usr/bin/env python3
"""Fast exact bookkeeping replay of the executed cell-bound receipts.

The full check_dual.py proves each emitted rational cell bound. This script
checks complete covers, exact cap-penalty sums, reference feasibility, the
closed Q integrals, and the analytic tail independently of their aggregation.
"""
import csv
import json
import sys
from fractions import Fraction as F
from pathlib import Path
from flint import ctx
sys.dont_write_bytecode = True
from check_dual import Certificate, ar

HERE=Path(__file__).resolve().parent
ctx.dps=70
receipt=json.loads((HERE/'certificate.json').read_text())
reference=json.loads((HERE/'reference.json').read_text())
c=Certificate(reference)

def rows(name):
    with (HERE/name).open() as f:
        r=csv.DictReader(f)
        return sorted([(F(x['left_endpoint']),F(x['right_endpoint']),F(x['rational_potential_lower_bound'])) for x in r],key=lambda x:x[0])

def cover(items,a,b):
    pos=a
    for left,right,lower in items:
        assert left==pos and left<right
        pos=right
    assert pos==b

he=F(-669,200); hm=F(71,25)
cont=rows('contour_cells.csv')
cover(cont,F(0),F(1))
assert len(cont)==receipt['contour']['accepted_cells']
assert all(lower>=he for a,b,lower in cont)

pin=rows('pinned_cells.csv')
freq=rows('frequency_cells.csv')
cover(pin,F(1,4),F(5,4)); cover(freq,F(1,2),F(81,10))
P=sum(((b-a)*max(he-lower,0) for a,b,lower in pin),F(0))
T=sum(((b-a)*max(hm-lower,0) for a,b,lower in freq),F(0))
assert P==F(receipt['pinned_positive_part']['exact_rational_upper_bound'])
assert T==F(receipt['frequency_positive_part']['exact_rational_upper_bound'])
q,parts=c.Q()
endpoint=c.Wfreq(ar(F(81,10)))
assert endpoint.lower()>ar(hm)
tail=F(81,10)
slope=F(693,1000)-1/(2*(tail-F(1,2)))+3/(tail+2)-2/(tail-F(11,2))-1/(tail-F(751,5000))
assert slope==F(receipt['tail']['derivative_rational_lower_bound']) and slope>F(1,50)
assert c.ln2.lower()>ar(F(693,1000))
bound=c.const+q+ar(he)+ar(hm)-ar(P)-ar(T)
assert bound.lower()>ar(F(receipt['certified_rational_lower_bound']))
assert bound.lower()>ar(F(199,100))
print('PASS: exact covers, rational cap sums, exact reference, closed Q, and infinite tail')
print('Recomputed directed bound:',bound)
print('alpha_Gamma >',receipt['certified_rational_lower_bound'],'> 199/100')
