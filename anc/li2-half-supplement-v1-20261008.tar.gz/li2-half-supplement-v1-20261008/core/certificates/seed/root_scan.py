#!/usr/bin/env python3
"""Finite field root scan of the same STAGE2 P0 polynomial at m=32."""
from math import comb
from pathlib import Path
import json
import resource
import time
from seed_check import stage2_mod, determinant_mod, json_bytes

OUT=Path(__file__).resolve().parent


def det_at_t(matrix,m,p,t):
    A=[row[:] for row in matrix]
    for ii,i in enumerate(range(m//4,5*m//4)):
        A[m+ii][i]=(A[m+ii][i] - t*comb(i+m//2,m//2)*pow(2,i,p)) % p
    return determinant_mod(A,p)[0]


def interpolate_equispaced(values,p):
    # Newton forward interpolation, in the basis binom(T,k).
    coefficients=[0]*len(values)
    differences=values[:]
    basis=[1]
    for k in range(len(values)):
        for j,b in enumerate(basis):
            coefficients[j]=(coefficients[j]+differences[0]*b) % p
        differences=[(differences[j+1]-differences[j]) % p
                     for j in range(len(differences)-1)]
        next_basis=[0]*(len(basis)+1)
        reciprocal=pow(k+1,-1,p)
        for j,b in enumerate(basis):
            next_basis[j]=(next_basis[j]-k*b*reciprocal) % p
            next_basis[j+1]=(next_basis[j+1]+b*reciprocal) % p
        basis=next_basis
    return coefficients


def evaluate(coefficients,t,p):
    result=0
    for c in reversed(coefficients):
        result=(result*t+c) % p
    return result


def main():
    start=time.monotonic()
    records=[]
    for p in (83,89,97,101,103,107,109):
        m=32
        matrix=stage2_mod(m,p)
        # Exhaustive direct determinant evaluation, with interpolation as a
        # separate cross-check of the degree bound and evaluations.
        values=[det_at_t(matrix,m,p,t) for t in range(p)]
        roots=[t for t,v in enumerate(values) if not v]
        coefficients=interpolate_equispaced(values[:m+1],p)
        assert all(evaluate(coefficients,t,p)==v for t,v in enumerate(values))
        # Leading coefficient obtained by multilinearity, independently of
        # interpolation: bottom rows consist only of -A.
        leading_matrix=[row[:] for row in matrix[:m]]+[[0]*(2*m) for _ in range(m)]
        for ii,i in enumerate(range(m//4,5*m//4)):
            leading_matrix[m+ii][i]=-comb(i+m//2,m//2)*pow(2,i,p) % p
        leading=determinant_mod(leading_matrix,p)[0]
        assert leading==coefficients[m]
        record={'m':m,'g':m//2,'p':p,'constant_coefficient_mod_p':values[0],
                'leading_coefficient_mod_p':leading,
                'degree':max(i for i,v in enumerate(coefficients) if v),
                'coefficients_ascending':coefficients,
                'all_residue_values_in_order':values,'roots_mod_p':roots,
                'direct_determinant_evaluations':p,
                'interpolation_matches_all_evaluations':True,
                'independent_leading_coefficient_matches':True,
                'no_Qp_root_by_integrality_and_unit_leading':not roots and bool(leading)}
        records.append(record)
        print(json.dumps({k:v for k,v in record.items()
                          if k not in ('coefficients_ascending','all_residue_values_in_order')}),flush=True)
        if record['no_Qp_root_by_integrality_and_unit_leading']:
            break
    result={'records':records,'elapsed_seconds':time.monotonic()-start,
            'maximum_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'maximum_m':32}
    (OUT/'root_scan.json').write_bytes(json_bytes(result))
    print(json.dumps({k:v for k,v in result.items() if k!='records'}),flush=True)

if __name__=='__main__':
    main()
