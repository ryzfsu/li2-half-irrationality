#!/usr/bin/env python3
"""Independent STAGE2 constant-seed checks; standard library only.

No polynomial interpolation and no determinant with m>32 occurs here.
Fractions use the literal formulas in staged PROPK.md section 1.
"""
from fractions import Fraction as F
from math import comb, isqrt
from pathlib import Path
import hashlib
import json
import resource
import sys
import time

OUT = Path(__file__).resolve().parent


def stage2_rational(m):
    assert m % 4 == 0 and 4 <= m <= 64
    g = m // 2
    indices = list(range(m // 4, 5 * m // 4))
    width = 2 * m
    U = [comb(n + g, g) * (1 << n) for n in range(width)]
    H = [F(0)]
    for n in range(1, width + g):
        H.append(H[-1] + F(1, n))
    T = []
    for n in range(width):
        s1 = sum((F(U[n-r], r) for r in range(1, n+1)), F(0))
        s2 = sum((F((-1)**(k-1) * comb(n+g, g-k) * ((1 << k)-1), k)
                  for k in range(1, g+1)), F(0))
        T.append(s1 + (1 << n) * s2)
    C, B = [], []
    for i in indices:
        c_row, b_row = [], []
        for j in range(width):
            if i != j:
                c_row.append(F(U[i]-U[j], j-i))
                b_row.append((T[i]-T[j]) / (j-i))
            else:
                c_row.append(-U[i]*(H[i+g]-H[i]))
                first = sum((F(U[i-r], r*r) for r in range(1, i+1)), F(0))
                second = sum((F((-1)**k * comb(i+g, g-k), k)
                              * sum((F((1 << h)-1, h) for h in range(1, k)), F(0))
                              for k in range(2, g+1)), F(0))
                b_row.append(first - (1 << i) * second)
        C.append(c_row)
        B.append(b_row)
    return C+B


def stage2_mod(m, p):
    """A separate modular implementation: recurrences, no rational objects."""
    assert m % 4 == 0 and 4 <= m <= 64
    assert p > 5*m//2 and all(p % d for d in range(2, isqrt(p)+1))
    g, width = m//2, 2*m
    inv = [0] + [pow(d, -1, p) for d in range(1, width+g)]
    powers = [1]
    for n in range(1, width+g):
        powers.append(2*powers[-1] % p)
    choose = [[0]*(g+1) for n in range(width+g)]
    choose[0][0] = 1
    for n in range(1, width+g):
        choose[n][0] = 1
        for k in range(1, min(g,n)+1):
            choose[n][k] = (choose[n-1][k]+choose[n-1][k-1]) % p
    U = [choose[n+g][g]*powers[n] % p for n in range(width)]
    # Prefix of (2^h-1)/h, used to build the diagonal B independently.
    inner = [0]
    for k in range(1, g+1):
        inner.append((inner[-1] + (powers[k]-1)*inv[k]) % p)
    T = []
    diag_B = []
    for n in range(width):
        s1 = sum(U[n-r]*inv[r] for r in range(1, n+1)) % p
        s2 = sum((-1)**(k-1)*choose[n+g][g-k]
                 *(powers[k]-1)*inv[k] for k in range(1, g+1)) % p
        T.append((s1 + powers[n]*s2) % p)
        b1 = sum(U[n-r]*inv[r]**2 for r in range(1,n+1)) % p
        b2 = sum((-1)**k*choose[n+g][g-k]*inv[k]*inner[k-1]
                 for k in range(2,g+1)) % p
        diag_B.append((b1-powers[n]*b2) % p)
    result = []
    for block in ('C', 'B'):
        for i in range(m//4,5*m//4):
            row = []
            for j in range(width):
                if i==j:
                    val = (-U[i]*sum(inv[h] for h in range(i+1,i+g+1))
                           if block=='C' else diag_B[i])
                else:
                    d=j-i
                    reciprocal=inv[abs(d)]*(1 if d>0 else -1)
                    val=((U[i]-U[j]) if block=='C' else (T[i]-T[j]))*reciprocal
                row.append(val % p)
            result.append(row)
    return result


def determinant_mod(matrix, p):
    """Gaussian determinant with unnormalized pivot rows and a certificate."""
    A = [row[:] for row in matrix]
    n=len(A)
    swaps, pivots = [], []
    for c in range(n):
        r=next((r for r in range(c,n) if A[r][c] % p), None)
        if r is None:
            return 0, {'rank_below':n, 'zero_pivot_column':c,
                       'pivots':pivots,'row_swaps':swaps}
        if r!=c:
            A[r], A[c]=A[c], A[r]
            swaps.append([c,r])
        pivot=A[c][c] % p
        pivots.append(pivot)
        pivot_inverse=pow(pivot,-1,p)
        for r in range(c+1,n):
            factor=A[r][c]*pivot_inverse % p
            A[r][c]=0
            if factor:
                for j in range(c+1,n):
                    A[r][j]=(A[r][j]-factor*A[c][j]) % p
    value=(-1)**len(swaps)
    for pivot in pivots:
        value=value*pivot % p
    return value, {'rank':n,'pivots':pivots,'row_swaps':swaps,
                   'product_pivots_mod_p':(value*(-1)**len(swaps)) % p}


def determinant_rational_small(matrix):
    A=[row[:] for row in matrix]
    value=F(1)
    for c in range(len(A)):
        r=next((r for r in range(c,len(A)) if A[r][c]),None)
        if r is None:
            return F(0)
        if r!=c:
            A[r],A[c]=A[c],A[r]
            value=-value
        pivot=A[c][c]
        value*=pivot
        for r in range(c+1,len(A)):
            factor=A[r][c]/pivot
            A[r][c]=F(0)
            for j in range(c+1,len(A)):
                A[r][j]-=factor*A[c][j]
    return value


def rational_reduce(matrix,p):
    return [[v.numerator*pow(v.denominator,-1,p) % p for v in row]
            for row in matrix]


def json_bytes(obj):
    return (json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()


def main():
    start=time.monotonic()
    result={'formula':'PROPK.md section 1 (literal STAGE2, g even)',
            'cases':[], 'no_full_polynomial':True,'maximum_m':32}
    for m, primes in ((4,(11,)),(32,(83,89,97,101))):
        rational=stage2_rational(m)
        exact=determinant_rational_small(rational) if m==4 else None
        if m==4:
            assert exact == F(693928939752246443,291600000)
        for p in primes:
            matrix=stage2_mod(m,p)
            reduced=rational_reduce(rational,p)
            assert matrix==reduced
            value,certificate=determinant_mod(matrix,p)
            if exact is not None:
                assert value==exact.numerator*pow(exact.denominator,-1,p) % p
            data={'m':m,'g':m//2,'I_half_open':[m//4,5*m//4],
                  'J_half_open':[0,2*m],'p':p,'matrix':matrix,
                  'determinant_mod_p':value,'elimination':certificate,
                  'entrywise_rational_modular_agreement':True,
                  'fraction_entries_compared':4*m*m}
            if exact is not None:
                data['exact_determinant']={'numerator':str(exact.numerator),
                                           'denominator':str(exact.denominator)}
            path=OUT/f'seed_m{m}_p{p}.json'
            content=json_bytes(data)
            path.write_bytes(content)
            result['cases'].append({k:v for k,v in data.items() if k not in ('matrix','elimination')}
                                     | {'matrix_file':path.name,
                                        'matrix_file_sha256':hashlib.sha256(content).hexdigest(),
                                        'rank':certificate.get('rank')})
    result['elapsed_seconds']=time.monotonic()-start
    result['maximum_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    (OUT/'results.json').write_bytes(json_bytes(result))
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':
    main()
