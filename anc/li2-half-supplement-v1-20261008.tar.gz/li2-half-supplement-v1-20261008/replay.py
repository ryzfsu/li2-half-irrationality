#!/usr/bin/env python3
"""Complete finite replay for "Irrationality of the dilogarithm at 1/2".

Checks SHA256SUMS, copies the bundle to a fresh directory and runs every
checker there in sequence. Requires python-flint and at least 20 GiB of
available memory. --quick runs only the light exact stages.
"""
from pathlib import Path
import argparse, hashlib, json, os, platform, resource, shutil, subprocess, sys, tempfile, time

B = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--quick', action='store_true')
p.add_argument('--out', type=Path)
a = p.parse_args()
for line in (B/'SHA256SUMS').read_text().splitlines():
    if line.strip():
        h, n = line.split(maxsplit=1)
        f = (B/n.lstrip('*')).resolve()
        assert f.is_relative_to(B) and f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest() == h, n
W = a.out.resolve() if a.out else Path(tempfile.mkdtemp(prefix='li2-half-replay-'))
assert W != B and not (W.exists() and any(W.iterdir()))
W.mkdir(parents=True, exist_ok=True)
for n in ['core', 'root_checks', 'independent']:
    shutil.copytree(B/n, W/n, dirs_exist_ok=True)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
C = W/'core/certificates'
def pre():
    os.nice(15)
    resource.setrlimit(resource.RLIMIT_AS, (6*1024**3, 6*1024**3))
def ram():
    d = {x.split(':')[0]: x.split(':')[1] for x in Path('/proc/meminfo').read_text().splitlines()}
    return int(d['MemAvailable'].split()[0])*1024
py = sys.executable
stages = [
    ('core_light', [py, str(W/'core/verify_bundle.py')], W/'core'),
    ('source_and_margins', [py, str(W/'root_checks/check_source_and_margins.py')], W/'root_checks'),
    ('arithmetic_integral', [py, str(C/'arithmetic/verify.py')], C/'arithmetic'),
    ('assembly', [py, str(C/'assembly/check_assembly.py')], C/'assembly'),
    ('linear_tail', [py, str(C/'linear_tail/check_tail.py')], C/'linear_tail'),
]
if not a.quick:
    stages += [
        ('directed_arb', [py, str(C/'dual/check_dual.py')], C/'dual'),
        ('independent_a', [py, str(W/'independent/a/checker.py')], W/'independent/a'),
        ('independent_b', [py, str(W/'independent/b/direct_only.py')], W/'independent/b'),
    ]
r = {'status': 'RUNNING', 'quick': a.quick, 'python': sys.version, 'platform': platform.platform(), 'stages': []}
t0 = time.monotonic()
for n, c, cwd in stages:
    av = ram()
    assert av >= 20*1024**3, 'MemAvailable<20GiB'
    print('START', n, flush=True)
    t = time.monotonic()
    with (W/(n+'.log')).open('w') as f:
        q = subprocess.run(c, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=7200, preexec_fn=pre)
    r['stages'].append({'name': n, 'exit_code': q.returncode, 'seconds': time.monotonic()-t, 'log': n+'.log'})
    (W/'REPLAY.json').write_text(json.dumps(r, indent=2)+'\n')
    assert q.returncode == 0, n
    print('PASS', n, flush=True)
r['status'] = 'PASS_QUICK' if a.quick else 'PASS_FULL'
r['elapsed_seconds'] = time.monotonic()-t0
(W/'REPLAY.json').write_text(json.dumps(r, indent=2)+'\n')
print(json.dumps(r, indent=2))
print('Output directory:', W)
